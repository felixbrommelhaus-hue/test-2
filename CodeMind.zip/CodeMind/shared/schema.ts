import { sql } from "drizzle-orm";
import { pgTable, text, varchar, boolean, timestamp, integer, jsonb, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email", { length: 255 }).notNull().unique(),
  password: text("password").notNull(),
  firstName: varchar("first_name", { length: 100 }).notNull(),
  lastName: varchar("last_name", { length: 100 }).notNull(),
  companyName: varchar("company_name", { length: 255 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const campaigns = pgTable("campaigns", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  isPublished: boolean("is_published").default(false).notNull(),
  publicUrlSlug: varchar("public_url_slug", { length: 100 }).unique(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const campaignModules = pgTable("campaign_modules", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: uuid("campaign_id").references(() => campaigns.id).notNull(),
  moduleType: varchar("module_type", { length: 50 }).notNull(), // 'header', 'text', 'quiz', 'lead_form', 'prize'
  content: jsonb("content").notNull(), // stores module-specific data
  position: integer("position").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const leads = pgTable("leads", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: uuid("campaign_id").references(() => campaigns.id).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  firstName: varchar("first_name", { length: 100 }),
  lastName: varchar("last_name", { length: 100 }),
  data: jsonb("data"), // additional form data
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const campaignAnalytics = pgTable("campaign_analytics", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: uuid("campaign_id").references(() => campaigns.id).notNull(),
  eventType: varchar("event_type", { length: 50 }).notNull(), // 'scan', 'view', 'interaction'
  eventData: jsonb("event_data"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  campaigns: many(campaigns),
}));

export const campaignsRelations = relations(campaigns, ({ one, many }) => ({
  user: one(users, {
    fields: [campaigns.userId],
    references: [users.id],
  }),
  modules: many(campaignModules),
  leads: many(leads),
  analytics: many(campaignAnalytics),
}));

export const campaignModulesRelations = relations(campaignModules, ({ one }) => ({
  campaign: one(campaigns, {
    fields: [campaignModules.campaignId],
    references: [campaigns.id],
  }),
}));

export const leadsRelations = relations(leads, ({ one }) => ({
  campaign: one(campaigns, {
    fields: [leads.campaignId],
    references: [campaigns.id],
  }),
}));

export const campaignAnalyticsRelations = relations(campaignAnalytics, ({ one }) => ({
  campaign: one(campaigns, {
    fields: [campaignAnalytics.campaignId],
    references: [campaigns.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  password: true,
  firstName: true,
  lastName: true,
  companyName: true,
});

export const insertCampaignSchema = createInsertSchema(campaigns).pick({
  name: true,
  description: true,
  isPublished: true,
  publicUrlSlug: true,
});

export const insertCampaignModuleSchema = createInsertSchema(campaignModules).pick({
  campaignId: true,
  moduleType: true,
  content: true,
  position: true,
});

export const insertLeadSchema = createInsertSchema(leads).pick({
  campaignId: true,
  email: true,
  firstName: true,
  lastName: true,
  data: true,
});

export const insertCampaignAnalyticsSchema = createInsertSchema(campaignAnalytics).pick({
  campaignId: true,
  eventType: true,
  eventData: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertCampaign = z.infer<typeof insertCampaignSchema>;
export type Campaign = typeof campaigns.$inferSelect;
export type InsertCampaignModule = z.infer<typeof insertCampaignModuleSchema>;
export type CampaignModule = typeof campaignModules.$inferSelect;
export type InsertLead = z.infer<typeof insertLeadSchema>;
export type Lead = typeof leads.$inferSelect;
export type InsertCampaignAnalytics = z.infer<typeof insertCampaignAnalyticsSchema>;
export type CampaignAnalytics = typeof campaignAnalytics.$inferSelect;

// Username field for auth compatibility
export const loginUserSchema = z.object({
  username: z.string().email(),
  password: z.string().min(8),
});

export type LoginUser = z.infer<typeof loginUserSchema>;

// Module content schemas for type safety
export const headerContentSchema = z.object({
  title: z.string(),
  subtitle: z.string().optional(),
  logoUrl: z.string().optional(),
});

export const textContentSchema = z.object({
  text: z.string(),
});

export const quizContentSchema = z.object({
  mode: z.enum(['knowledge', 'personality']),
  questions: z.array(z.object({
    question: z.string(),
    options: z.array(z.string()).min(2).max(4),
    correctAnswer: z.number().optional(), // Only for knowledge mode
  })),
  results: z.object({
    correct: z.string().optional(), // For knowledge mode
    incorrect: z.string().optional(), // For knowledge mode
    personality: z.record(z.string()).optional(), // For personality mode
  }),
  ctaText: z.string(),
  ctaAction: z.enum(['link', 'lead_form']),
  ctaLink: z.string().optional(),
});

export const prizeContentSchema = z.object({
  title: z.string(),
  instructionText: z.string(),
  scratchImageUrl: z.string().optional(),
  prizeImageUrl: z.string().optional(),
  winProbability: z.number().min(0).max(100),
  winConfig: z.object({
    title: z.string(),
    text: z.string(),
    action: z.enum(['text_only', 'lead_form', 'link']),
    actionData: z.string().optional(),
  }),
  loseConfig: z.object({
    title: z.string(),
    text: z.string(),
  }),
});

export const leadFormContentSchema = z.object({
  title: z.string(),
  fields: z.array(z.object({
    name: z.string(),
    type: z.enum(['text', 'email', 'tel', 'dropdown']),
    label: z.string(),
    required: z.boolean(),
    options: z.array(z.string()).optional(), // For dropdown
  })),
  gdprText: z.string(),
  gdprLink: z.string(),
  buttonText: z.string(),
  afterSubmitAction: z.enum(['thank_you', 'download', 'redirect']),
  afterSubmitData: z.string().optional(),
});

export type HeaderContent = z.infer<typeof headerContentSchema>;
export type TextContent = z.infer<typeof textContentSchema>;
export type QuizContent = z.infer<typeof quizContentSchema>;
export type PrizeContent = z.infer<typeof prizeContentSchema>;
export type LeadFormContent = z.infer<typeof leadFormContentSchema>;
