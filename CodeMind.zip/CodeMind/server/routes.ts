import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertCampaignSchema, insertCampaignModuleSchema, insertLeadSchema, insertCampaignAnalyticsSchema } from "@shared/schema";
import { nanoid } from "nanoid";
import QRCode from "qrcode";

export function registerRoutes(app: Express): Server {
  // Sets up /api/register, /api/login, /api/logout, /api/user
  setupAuth(app);

  // Campaign routes
  app.get("/api/campaigns", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    try {
      const campaigns = await storage.getCampaignsByUserId(req.user!.id);
      
      // Get analytics for each campaign
      const campaignsWithStats = await Promise.all(
        campaigns.map(async (campaign) => {
          const analytics = await storage.getCampaignAnalytics(campaign.id);
          return {
            ...campaign,
            ...analytics
          };
        })
      );

      res.json(campaignsWithStats);
    } catch (error) {
      console.error("Error fetching campaigns:", error);
      res.status(500).json({ message: "Failed to fetch campaigns" });
    }
  });

  app.post("/api/campaigns", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    try {
      const campaignData = insertCampaignSchema.parse(req.body);
      const publicUrlSlug = nanoid(10);
      
      const campaign = await storage.createCampaign({
        ...campaignData,
        userId: req.user!.id,
        publicUrlSlug
      });

      res.status(201).json(campaign);
    } catch (error) {
      console.error("Error creating campaign:", error);
      res.status(400).json({ message: "Failed to create campaign" });
    }
  });

  app.get("/api/campaigns/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    try {
      const campaign = await storage.getCampaignById(req.params.id);
      
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }

      // Check if user owns this campaign
      if (campaign.userId !== req.user!.id) {
        return res.sendStatus(403);
      }

      res.json(campaign);
    } catch (error) {
      console.error("Error fetching campaign:", error);
      res.status(500).json({ message: "Failed to fetch campaign" });
    }
  });

  app.put("/api/campaigns/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    try {
      const campaign = await storage.getCampaignById(req.params.id);
      
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }

      // Check if user owns this campaign
      if (campaign.userId !== req.user!.id) {
        return res.sendStatus(403);
      }

      const campaignData = insertCampaignSchema.partial().parse(req.body);
      const updatedCampaign = await storage.updateCampaign(req.params.id, campaignData);

      res.json(updatedCampaign);
    } catch (error) {
      console.error("Error updating campaign:", error);
      res.status(400).json({ message: "Failed to update campaign" });
    }
  });

  app.delete("/api/campaigns/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    try {
      const campaign = await storage.getCampaignById(req.params.id);
      
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }

      // Check if user owns this campaign
      if (campaign.userId !== req.user!.id) {
        return res.sendStatus(403);
      }

      const deleted = await storage.deleteCampaign(req.params.id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Campaign not found" });
      }

      res.sendStatus(204);
    } catch (error) {
      console.error("Error deleting campaign:", error);
      res.status(500).json({ message: "Failed to delete campaign" });
    }
  });

  // Campaign modules routes
  app.get("/api/campaigns/:id/modules", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    try {
      const campaign = await storage.getCampaignById(req.params.id);
      
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }

      // Check if user owns this campaign
      if (campaign.userId !== req.user!.id) {
        return res.sendStatus(403);
      }

      const modules = await storage.getModulesByCampaignId(req.params.id);
      res.json(modules);
    } catch (error) {
      console.error("Error fetching campaign modules:", error);
      res.status(500).json({ message: "Failed to fetch campaign modules" });
    }
  });

  app.post("/api/campaigns/:id/modules", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    try {
      const campaign = await storage.getCampaignById(req.params.id);
      
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }

      // Check if user owns this campaign
      if (campaign.userId !== req.user!.id) {
        return res.sendStatus(403);
      }

      const moduleData = insertCampaignModuleSchema.parse({
        ...req.body,
        campaignId: req.params.id
      });

      const module = await storage.createCampaignModule(moduleData);
      res.status(201).json(module);
    } catch (error) {
      console.error("Error creating campaign module:", error);
      res.status(400).json({ message: "Failed to create campaign module" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    try {
      const stats = await storage.getCampaignStats(req.user!.id);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // QR Code generation
  app.get("/api/campaigns/:id/qr", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    try {
      const campaign = await storage.getCampaignById(req.params.id);
      
      if (!campaign) {
        return res.status(404).json({ message: "Campaign not found" });
      }

      // Check if user owns this campaign
      if (campaign.userId !== req.user!.id) {
        return res.sendStatus(403);
      }

      if (!campaign.publicUrlSlug) {
        return res.status(400).json({ message: "Campaign not published" });
      }

      const domains = process.env.REPLIT_DOMAINS?.split(',') || ['localhost:5000'];
      const baseUrl = `https://${domains[0]}`;
      const campaignUrl = `${baseUrl}/c/${campaign.publicUrlSlug}`;

      const format = req.query.format as string;
      
      if (format === 'svg') {
        const svgString = await QRCode.toString(campaignUrl, { type: 'svg' });
        res.setHeader('Content-Type', 'image/svg+xml');
        res.setHeader('Content-Disposition', `attachment; filename="${campaign.name}-qr.svg"`);
        res.send(svgString);
      } else {
        const pngBuffer = await QRCode.toBuffer(campaignUrl, { type: 'png' });
        res.setHeader('Content-Type', 'image/png');
        res.setHeader('Content-Disposition', `attachment; filename="${campaign.name}-qr.png"`);
        res.send(pngBuffer);
      }
    } catch (error) {
      console.error("Error generating QR code:", error);
      res.status(500).json({ message: "Failed to generate QR code" });
    }
  });

  // Public campaign view (for QR code links)
  app.get("/c/:slug", async (req, res) => {
    try {
      const campaign = await storage.getCampaignBySlug(req.params.slug);
      
      if (!campaign || !campaign.isPublished) {
        return res.status(404).send("Campaign not found");
      }

      // Track the scan
      await storage.createAnalyticsEvent({
        campaignId: campaign.id,
        eventType: 'scan',
        eventData: { userAgent: req.get('User-Agent'), ip: req.ip }
      });

      // Get campaign modules
      const modules = await storage.getModulesByCampaignId(campaign.id);

      // Return a simple HTML page that renders the campaign
      res.send(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>${campaign.name}</title>
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <script src="https://cdn.tailwindcss.com"></script>
        </head>
        <body class="bg-gray-50 min-h-screen">
          <div class="max-w-md mx-auto py-8 px-4">
            <h1 class="text-2xl font-bold text-gray-900 mb-6">${campaign.name}</h1>
            <div class="space-y-6">
              ${modules.map(module => `
                <div class="bg-white rounded-lg p-6 shadow-sm">
                  ${renderModule(module)}
                </div>
              `).join('')}
            </div>
          </div>
        </body>
        </html>
      `);
    } catch (error) {
      console.error("Error serving campaign:", error);
      res.status(500).send("Error loading campaign");
    }
  });

  // Lead submission endpoint
  app.post("/api/campaigns/:slug/leads", async (req, res) => {
    try {
      const campaign = await storage.getCampaignBySlug(req.params.slug);
      
      if (!campaign || !campaign.isPublished) {
        return res.status(404).json({ message: "Campaign not found" });
      }

      const leadData = insertLeadSchema.parse({
        ...req.body,
        campaignId: campaign.id
      });

      const lead = await storage.createLead(leadData);
      res.status(201).json(lead);
    } catch (error) {
      console.error("Error creating lead:", error);
      res.status(400).json({ message: "Failed to create lead" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function renderModule(module: any): string {
  switch (module.moduleType) {
    case 'header':
      return `
        <div class="text-center">
          <h2 class="text-xl font-bold">${module.content.title || 'Header'}</h2>
          ${module.content.subtitle ? `<p class="text-gray-600 mt-2">${module.content.subtitle}</p>` : ''}
        </div>
      `;
    case 'text':
      return `<p class="text-gray-700">${module.content.text || 'Text content'}</p>`;
    case 'quiz':
      return `
        <div>
          <h3 class="font-semibold mb-4">${module.content.question || 'Quiz Question'}</h3>
          <div class="space-y-2">
            ${(module.content.options || []).map((option: string, index: number) => `
              <button class="w-full text-left p-3 border rounded-lg hover:bg-gray-50" onclick="selectAnswer(${index})">
                ${option}
              </button>
            `).join('')}
          </div>
        </div>
      `;
    case 'lead_form':
      return `
        <form onsubmit="submitLead(event)">
          <h3 class="font-semibold mb-4">${module.content.title || 'Contact Information'}</h3>
          <div class="space-y-3">
            <input type="text" name="firstName" placeholder="Vorname" class="w-full p-3 border rounded-lg" required>
            <input type="text" name="lastName" placeholder="Nachname" class="w-full p-3 border rounded-lg" required>
            <input type="email" name="email" placeholder="E-Mail" class="w-full p-3 border rounded-lg" required>
            <label class="flex items-start space-x-2">
              <input type="checkbox" required class="mt-1">
              <span class="text-sm text-gray-600">Ich stimme der Verarbeitung meiner Daten zu (DSGVO)</span>
            </label>
            <button type="submit" class="w-full bg-blue-600 text-white p-3 rounded-lg font-medium">
              ${module.content.buttonText || 'Absenden'}
            </button>
          </div>
        </form>
      `;
    case 'prize':
      return `
        <div class="text-center">
          <h3 class="font-semibold mb-4">${module.content.title || 'Gewinnspiel'}</h3>
          <button onclick="playGame()" class="bg-yellow-500 text-white px-6 py-3 rounded-lg font-medium">
            ${module.content.buttonText || 'Jetzt teilnehmen'}
          </button>
        </div>
      `;
    default:
      return `<p class="text-gray-500">Unknown module type: ${module.moduleType}</p>`;
  }
}
