import { 
  users, campaigns, campaignModules, leads, campaignAnalytics,
  type User, type InsertUser, type Campaign, type InsertCampaign,
  type CampaignModule, type InsertCampaignModule, type Lead, type InsertLead,
  type CampaignAnalytics, type InsertCampaignAnalytics
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, count, sql } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Campaign methods
  getCampaignsByUserId(userId: string): Promise<Campaign[]>;
  getCampaignById(id: string): Promise<Campaign | undefined>;
  createCampaign(campaign: InsertCampaign & { userId: string }): Promise<Campaign>;
  updateCampaign(id: string, campaign: Partial<InsertCampaign>): Promise<Campaign | undefined>;
  deleteCampaign(id: string): Promise<boolean>;
  getCampaignBySlug(slug: string): Promise<Campaign | undefined>;
  
  // Campaign Module methods
  getModulesByCampaignId(campaignId: string): Promise<CampaignModule[]>;
  createCampaignModule(module: InsertCampaignModule): Promise<CampaignModule>;
  updateCampaignModule(id: string, module: Partial<InsertCampaignModule>): Promise<CampaignModule | undefined>;
  deleteCampaignModule(id: string): Promise<boolean>;
  
  // Lead methods
  getLeadsByCampaignId(campaignId: string): Promise<Lead[]>;
  createLead(lead: InsertLead): Promise<Lead>;
  
  // Analytics methods
  createAnalyticsEvent(analytics: InsertCampaignAnalytics): Promise<CampaignAnalytics>;
  getCampaignStats(userId: string): Promise<{
    activeCampaigns: number;
    totalScans: number;
    totalLeads: number;
    conversionRate: number;
  }>;
  getCampaignAnalytics(campaignId: string): Promise<{
    scans: number;
    leads: number;
    conversion: number;
  }>;
  
  sessionStore: any;
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Campaign methods
  async getCampaignsByUserId(userId: string): Promise<Campaign[]> {
    return await db
      .select()
      .from(campaigns)
      .where(eq(campaigns.userId, userId))
      .orderBy(desc(campaigns.createdAt));
  }

  async getCampaignById(id: string): Promise<Campaign | undefined> {
    const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return campaign || undefined;
  }

  async createCampaign(campaign: InsertCampaign & { userId: string }): Promise<Campaign> {
    const [newCampaign] = await db
      .insert(campaigns)
      .values(campaign)
      .returning();
    return newCampaign;
  }

  async updateCampaign(id: string, campaign: Partial<InsertCampaign>): Promise<Campaign | undefined> {
    const [updatedCampaign] = await db
      .update(campaigns)
      .set({ ...campaign, updatedAt: new Date() })
      .where(eq(campaigns.id, id))
      .returning();
    return updatedCampaign || undefined;
  }

  async deleteCampaign(id: string): Promise<boolean> {
    const result = await db.delete(campaigns).where(eq(campaigns.id, id));
    return result.rowCount > 0;
  }

  async getCampaignBySlug(slug: string): Promise<Campaign | undefined> {
    const [campaign] = await db.select().from(campaigns).where(eq(campaigns.publicUrlSlug, slug));
    return campaign || undefined;
  }

  // Campaign Module methods
  async getModulesByCampaignId(campaignId: string): Promise<CampaignModule[]> {
    return await db
      .select()
      .from(campaignModules)
      .where(eq(campaignModules.campaignId, campaignId))
      .orderBy(campaignModules.position);
  }

  async createCampaignModule(module: InsertCampaignModule): Promise<CampaignModule> {
    const [newModule] = await db
      .insert(campaignModules)
      .values(module)
      .returning();
    return newModule;
  }

  async updateCampaignModule(id: string, module: Partial<InsertCampaignModule>): Promise<CampaignModule | undefined> {
    const [updatedModule] = await db
      .update(campaignModules)
      .set(module)
      .where(eq(campaignModules.id, id))
      .returning();
    return updatedModule || undefined;
  }

  async deleteCampaignModule(id: string): Promise<boolean> {
    const result = await db.delete(campaignModules).where(eq(campaignModules.id, id));
    return result.rowCount > 0;
  }

  // Lead methods
  async getLeadsByCampaignId(campaignId: string): Promise<Lead[]> {
    return await db
      .select()
      .from(leads)
      .where(eq(leads.campaignId, campaignId))
      .orderBy(desc(leads.createdAt));
  }

  async createLead(lead: InsertLead): Promise<Lead> {
    const [newLead] = await db
      .insert(leads)
      .values(lead)
      .returning();
    return newLead;
  }

  // Analytics methods
  async createAnalyticsEvent(analytics: InsertCampaignAnalytics): Promise<CampaignAnalytics> {
    const [newEvent] = await db
      .insert(campaignAnalytics)
      .values(analytics)
      .returning();
    return newEvent;
  }

  async getCampaignStats(userId: string): Promise<{
    activeCampaigns: number;
    totalScans: number;
    totalLeads: number;
    conversionRate: number;
  }> {
    // Get active campaigns count
    const [activeCampaignsResult] = await db
      .select({ count: count() })
      .from(campaigns)
      .where(eq(campaigns.userId, userId));

    // Get total scans across all user campaigns
    const [totalScansResult] = await db
      .select({ count: count() })
      .from(campaignAnalytics)
      .innerJoin(campaigns, eq(campaignAnalytics.campaignId, campaigns.id))
      .where(eq(campaigns.userId, userId));

    // Get total leads across all user campaigns
    const [totalLeadsResult] = await db
      .select({ count: count() })
      .from(leads)
      .innerJoin(campaigns, eq(leads.campaignId, campaigns.id))
      .where(eq(campaigns.userId, userId));

    const activeCampaigns = activeCampaignsResult.count;
    const totalScans = totalScansResult.count;
    const totalLeads = totalLeadsResult.count;
    const conversionRate = totalScans > 0 ? Math.round((totalLeads / totalScans) * 100) : 0;

    return {
      activeCampaigns,
      totalScans,
      totalLeads,
      conversionRate
    };
  }

  async getCampaignAnalytics(campaignId: string): Promise<{
    scans: number;
    leads: number;
    conversion: number;
  }> {
    // Get scans for this campaign
    const [scansResult] = await db
      .select({ count: count() })
      .from(campaignAnalytics)
      .where(eq(campaignAnalytics.campaignId, campaignId));

    // Get leads for this campaign
    const [leadsResult] = await db
      .select({ count: count() })
      .from(leads)
      .where(eq(leads.campaignId, campaignId));

    const scans = scansResult.count;
    const leadsCount = leadsResult.count;
    const conversion = scans > 0 ? Math.round((leadsCount / scans) * 100) : 0;

    return {
      scans,
      leads: leadsCount,
      conversion
    };
  }
}

export const storage = new DatabaseStorage();
