import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { PrizeContent } from "@shared/schema";

interface ScratchOffGameProps {
  content: PrizeContent;
  onGameComplete?: (won: boolean) => void;
  onLeadFormRequired?: () => void;
}

export function ScratchOffGame({ content, onGameComplete, onLeadFormRequired }: ScratchOffGameProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isScratching, setIsScratching] = useState(false);
  const [gameResult, setGameResult] = useState<'playing' | 'won' | 'lost'>('playing');
  const [scratchPercentage, setScratchPercentage] = useState(0);
  const [hasStarted, setHasStarted] = useState(false);

  // Determine win/lose result when game starts
  const [isWinner] = useState(() => {
    return Math.random() * 100 < content.winProbability;
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = 300;
    canvas.height = 200;

    // Draw scratch surface
    ctx.fillStyle = '#c0c0c0';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Add scratch surface pattern
    ctx.fillStyle = '#a0a0a0';
    ctx.font = '16px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Zum Aufrubbeln', canvas.width / 2, canvas.height / 2 - 10);
    ctx.fillText('hier wischen', canvas.width / 2, canvas.height / 2 + 10);

    // Prepare prize background
    const drawPrizeBackground = () => {
      ctx.globalCompositeOperation = 'destination-over';
      if (isWinner) {
        ctx.fillStyle = '#10b981'; // Green for win
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = 'white';
        ctx.font = 'bold 24px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('GEWINN!', canvas.width / 2, canvas.height / 2);
      } else {
        ctx.fillStyle = '#ef4444'; // Red for lose
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = 'white';
        ctx.font = 'bold 20px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('Leider nicht', canvas.width / 2, canvas.height / 2 - 10);
        ctx.fillText('gewonnen', canvas.width / 2, canvas.height / 2 + 15);
      }
      ctx.globalCompositeOperation = 'source-over';
    };

    drawPrizeBackground();
  }, [isWinner]);

  const handleScratch = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas || gameResult !== 'playing') return;

    if (!hasStarted) {
      setHasStarted(true);
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    let clientX: number, clientY: number;

    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const x = clientX - rect.left;
    const y = clientY - rect.top;

    // Scratch effect
    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.arc(x, y, 20, 0, 2 * Math.PI);
    ctx.fill();

    // Calculate scratch percentage
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const pixels = imageData.data;
    let transparentPixels = 0;

    for (let i = 3; i < pixels.length; i += 4) {
      if (pixels[i] === 0) transparentPixels++;
    }

    const percentage = (transparentPixels / (canvas.width * canvas.height)) * 100;
    setScratchPercentage(percentage);

    // Reveal result when 30% is scratched
    if (percentage > 30 && gameResult === 'playing') {
      const result = isWinner ? 'won' : 'lost';
      setGameResult(result);
      onGameComplete?.(isWinner);
    }
  };

  const handleAction = () => {
    const config = gameResult === 'won' ? content.winConfig : content.loseConfig;
    
    if (gameResult === 'won' && content.winConfig.action === 'lead_form') {
      onLeadFormRequired?.();
    } else if (gameResult === 'won' && content.winConfig.action === 'link' && content.winConfig.actionData) {
      window.open(content.winConfig.actionData, '_blank');
    }
  };

  if (gameResult !== 'playing') {
    const config = gameResult === 'won' ? content.winConfig : content.loseConfig;
    
    return (
      <div className="bg-white rounded-lg p-6 shadow-sm border text-center">
        <div className={`w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center ${
          gameResult === 'won' ? 'bg-green-100' : 'bg-red-100'
        }`}>
          <span className={`text-2xl ${gameResult === 'won' ? 'text-green-600' : 'text-red-600'}`}>
            {gameResult === 'won' ? '🎉' : '😔'}
          </span>
        </div>
        
        <h3 className="text-xl font-bold mb-2">{config.title}</h3>
        <p className="text-gray-600 mb-4">{config.text}</p>
        
        {gameResult === 'won' && content.winConfig.action !== 'text_only' && (
          <Button onClick={handleAction} className="w-full">
            {content.winConfig.action === 'lead_form' ? 'Preis einlösen' : 'Mehr erfahren'}
          </Button>
        )}
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg p-6 shadow-sm border">
      <div className="text-center mb-4">
        <h3 className="text-xl font-bold mb-2">{content.title}</h3>
        <p className="text-gray-600">{content.instructionText}</p>
      </div>
      
      <div className="flex justify-center mb-4">
        <canvas
          ref={canvasRef}
          className="border rounded-lg cursor-pointer touch-none"
          onMouseDown={() => setIsScratching(true)}
          onMouseUp={() => setIsScratching(false)}
          onMouseLeave={() => setIsScratching(false)}
          onMouseMove={(e) => isScratching && handleScratch(e)}
          onTouchStart={() => setIsScratching(true)}
          onTouchEnd={() => setIsScratching(false)}
          onTouchMove={handleScratch}
          data-testid="scratch-canvas"
        />
      </div>
      
      {hasStarted && gameResult === 'playing' && (
        <div className="text-center text-sm text-gray-500">
          {scratchPercentage < 30 ? 'Weiter rubbeln...' : 'Fast geschafft!'}
        </div>
      )}
    </div>
  );
}