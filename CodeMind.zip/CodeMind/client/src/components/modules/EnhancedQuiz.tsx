import { useState } from "react";
import { Button } from "@/components/ui/button";
import { QuizContent } from "@shared/schema";
import { CheckCircle, XCircle, ArrowRight } from "lucide-react";

interface EnhancedQuizProps {
  content: QuizContent;
  onQuizComplete?: (results: { answers: number[], score?: number, personality?: string }) => void;
  onLeadFormRequired?: () => void;
}

export function EnhancedQuiz({ content, onQuizComplete, onLeadFormRequired }: EnhancedQuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [quizResult, setQuizResult] = useState<string>('');

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
  };

  const handleNextQuestion = () => {
    if (selectedAnswer === null) return;

    const newAnswers = [...answers, selectedAnswer];
    setAnswers(newAnswers);

    if (currentQuestion < content.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
    } else {
      // Quiz completed
      completeQuiz(newAnswers);
    }
  };

  const completeQuiz = (finalAnswers: number[]) => {
    let result = '';
    let score = 0;

    if (content.mode === 'knowledge') {
      // Calculate score for knowledge quiz
      content.questions.forEach((question, index) => {
        if (question.correctAnswer !== undefined && finalAnswers[index] === question.correctAnswer) {
          score++;
        }
      });

      const percentage = (score / content.questions.length) * 100;
      result = percentage >= 70 ? (content.results.correct || 'Gut gemacht!') : (content.results.incorrect || 'Mehr Übung nötig!');
      
      onQuizComplete?.({ answers: finalAnswers, score: percentage });
    } else {
      // Personality test - determine most common answer or use first answer
      const answerCounts = finalAnswers.reduce((acc, answer) => {
        acc[answer] = (acc[answer] || 0) + 1;
        return acc;
      }, {} as Record<number, number>);

      const dominantAnswer = Object.entries(answerCounts).reduce((a, b) => 
        answerCounts[parseInt(a[0])] > answerCounts[parseInt(b[0])] ? a : b
      )[0];

      const personalityKey = String.fromCharCode(65 + parseInt(dominantAnswer)); // A, B, C, D
      result = content.results.personality?.[personalityKey] || 'Interessante Persönlichkeit!';
      
      onQuizComplete?.({ answers: finalAnswers, personality: personalityKey });
    }

    setQuizResult(result);
    setShowResult(true);
  };

  const handleCTA = () => {
    if (content.ctaAction === 'lead_form') {
      onLeadFormRequired?.();
    } else if (content.ctaAction === 'link' && content.ctaLink) {
      window.open(content.ctaLink, '_blank');
    }
  };

  if (showResult) {
    return (
      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-primary/10 rounded-full mx-auto mb-4 flex items-center justify-center">
            {content.mode === 'knowledge' ? (
              answers.filter((answer, index) => 
                content.questions[index].correctAnswer === answer
              ).length >= Math.ceil(content.questions.length * 0.7) ? (
                <CheckCircle className="h-8 w-8 text-green-600" />
              ) : (
                <XCircle className="h-8 w-8 text-orange-600" />
              )
            ) : (
              <span className="text-2xl">🎯</span>
            )}
          </div>
          
          <h3 className="text-xl font-bold mb-2">
            {content.mode === 'knowledge' ? 'Quiz abgeschlossen!' : 'Ihre Persönlichkeit'}
          </h3>
          
          <div className="text-gray-600 mb-6 whitespace-pre-line">
            {quizResult}
          </div>

          {content.mode === 'knowledge' && (
            <div className="text-sm text-gray-500 mb-4">
              Richtige Antworten: {answers.filter((answer, index) => 
                content.questions[index].correctAnswer === answer
              ).length} von {content.questions.length}
            </div>
          )}
        </div>

        <Button onClick={handleCTA} className="w-full" data-testid="quiz-cta-button">
          {content.ctaText}
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    );
  }

  const question = content.questions[currentQuestion];
  const progress = ((currentQuestion + 1) / content.questions.length) * 100;

  return (
    <div className="bg-white rounded-lg p-6 shadow-sm border">
      {/* Progress bar */}
      <div className="mb-6">
        <div className="flex justify-between text-sm text-gray-600 mb-2">
          <span>Frage {currentQuestion + 1} von {content.questions.length}</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-primary h-2 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Question */}
      <div className="mb-6">
        <h3 className="text-lg font-semibold mb-4" data-testid={`question-${currentQuestion}`}>
          {question.question}
        </h3>

        <div className="space-y-3">
          {question.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswerSelect(index)}
              className={`w-full text-left p-4 border-2 rounded-lg transition-all ${
                selectedAnswer === index
                  ? 'border-primary bg-primary/5 text-primary'
                  : 'border-gray-200 hover:border-gray-300 text-gray-700'
              }`}
              data-testid={`answer-option-${index}`}
            >
              <div className="flex items-center">
                <div className={`w-4 h-4 rounded-full border-2 mr-3 ${
                  selectedAnswer === index ? 'border-primary bg-primary' : 'border-gray-300'
                }`}>
                  {selectedAnswer === index && (
                    <div className="w-full h-full rounded-full bg-white" style={{ transform: 'scale(0.4)' }} />
                  )}
                </div>
                <span className="font-medium">{String.fromCharCode(65 + index)}.</span>
                <span className="ml-2">{option}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Next button */}
      <Button
        onClick={handleNextQuestion}
        disabled={selectedAnswer === null}
        className="w-full"
        data-testid="quiz-next-button"
      >
        {currentQuestion < content.questions.length - 1 ? 'Nächste Frage' : 'Quiz beenden'}
        <ArrowRight className="ml-2 h-4 w-4" />
      </Button>
    </div>
  );
}