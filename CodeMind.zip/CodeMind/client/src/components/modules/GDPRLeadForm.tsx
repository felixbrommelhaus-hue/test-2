import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LeadFormContent } from "@shared/schema";
import { Shield, Download, ExternalLink, CheckCircle } from "lucide-react";

interface GDPRLeadFormProps {
  content: LeadFormContent;
  campaignId: string;
  onSubmitSuccess?: (leadData: any) => void;
}

export function GDPRLeadForm({ content, campaignId, onSubmitSuccess }: GDPRLeadFormProps) {
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [gdprConsent, setGdprConsent] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    content.fields.forEach(field => {
      if (field.required && !formData[field.name]) {
        newErrors[field.name] = `${field.label} ist erforderlich`;
      }

      if (field.type === 'email' && formData[field.name]) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(formData[field.name])) {
          newErrors[field.name] = 'Bitte geben Sie eine gültige E-Mail-Adresse ein';
        }
      }

      if (field.type === 'tel' && formData[field.name]) {
        const phoneRegex = /^[\+]?[0-9\s\-\(\)]{6,}$/;
        if (!phoneRegex.test(formData[field.name])) {
          newErrors[field.name] = 'Bitte geben Sie eine gültige Telefonnummer ein';
        }
      }
    });

    if (!gdprConsent) {
      newErrors.gdpr = 'Sie müssen der Datenschutzerklärung zustimmen';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsSubmitting(true);

    try {
      const leadData = {
        campaignId,
        email: formData.email || '',
        firstName: formData.firstName || '',
        lastName: formData.lastName || '',
        data: {
          ...formData,
          gdprConsent: true,
          gdprConsentTimestamp: new Date().toISOString(),
          submissionSource: 'campaign_form'
        }
      };

      const response = await fetch(`/api/campaigns/${campaignId}/leads`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(leadData),
        credentials: 'include'
      });

      if (!response.ok) {
        throw new Error('Fehler beim Senden des Formulars');
      }

      setIsSubmitted(true);
      onSubmitSuccess?.(leadData);
    } catch (error) {
      setErrors({ submit: 'Fehler beim Senden. Bitte versuchen Sie es erneut.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFieldChange = (fieldName: string, value: string) => {
    setFormData(prev => ({ ...prev, [fieldName]: value }));
    // Clear error when user starts typing
    if (errors[fieldName]) {
      setErrors(prev => ({ ...prev, [fieldName]: '' }));
    }
  };

  const handleAfterSubmitAction = () => {
    switch (content.afterSubmitAction) {
      case 'download':
        if (content.afterSubmitData) {
          window.open(content.afterSubmitData, '_blank');
        }
        break;
      case 'redirect':
        if (content.afterSubmitData) {
          window.open(content.afterSubmitData, '_blank');
        }
        break;
      default:
        // thank_you - already shown
        break;
    }
  };

  if (isSubmitted) {
    return (
      <div className="bg-white rounded-lg p-6 shadow-sm border">
        <div className="text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full mx-auto mb-4 flex items-center justify-center">
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          
          <h3 className="text-xl font-bold mb-2">Vielen Dank!</h3>
          <p className="text-gray-600 mb-6">
            Ihre Daten wurden erfolgreich übermittelt. Wir werden uns in Kürze bei Ihnen melden.
          </p>

          {content.afterSubmitAction !== 'thank_you' && (
            <Button onClick={handleAfterSubmitAction} className="w-full">
              {content.afterSubmitAction === 'download' && <Download className="mr-2 h-4 w-4" />}
              {content.afterSubmitAction === 'redirect' && <ExternalLink className="mr-2 h-4 w-4" />}
              {content.afterSubmitAction === 'download' ? 'Download starten' : 'Weiter'}
            </Button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg p-6 shadow-sm border">
      <div className="mb-6">
        <h3 className="text-xl font-bold mb-2">{content.title}</h3>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {content.fields.map((field, index) => (
          <div key={field.name} className="space-y-2">
            <Label htmlFor={field.name} className="flex items-center">
              {field.label}
              {field.required && <span className="text-red-500 ml-1">*</span>}
            </Label>
            
            {field.type === 'dropdown' ? (
              <Select 
                value={formData[field.name] || ''} 
                onValueChange={(value) => handleFieldChange(field.name, value)}
              >
                <SelectTrigger data-testid={`field-${field.name}`}>
                  <SelectValue placeholder="Bitte wählen..." />
                </SelectTrigger>
                <SelectContent>
                  {field.options?.map((option, optionIndex) => (
                    <SelectItem key={optionIndex} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <Input
                id={field.name}
                name={field.name}
                type={field.type}
                value={formData[field.name] || ''}
                onChange={(e) => handleFieldChange(field.name, e.target.value)}
                placeholder={field.type === 'email' ? 'ihre.email@firma.de' : 
                           field.type === 'tel' ? '+49 123 456789' : ''}
                required={field.required}
                data-testid={`field-${field.name}`}
              />
            )}
            
            {errors[field.name] && (
              <p className="text-red-500 text-sm">{errors[field.name]}</p>
            )}
          </div>
        ))}

        {/* GDPR Consent */}
        <div className="border-t pt-4 mt-6">
          <div className="flex items-start space-x-3">
            <div className="flex items-center mt-1">
              <Checkbox
                id="gdpr-consent"
                checked={gdprConsent}
                onCheckedChange={(checked) => {
                  setGdprConsent(!!checked);
                  if (errors.gdpr) {
                    setErrors(prev => ({ ...prev, gdpr: '' }));
                  }
                }}
                data-testid="gdpr-checkbox"
              />
            </div>
            <div className="flex-1">
              <Label htmlFor="gdpr-consent" className="text-sm leading-relaxed cursor-pointer">
                <div className="flex items-start">
                  <Shield className="h-4 w-4 text-gray-500 mr-2 mt-0.5 flex-shrink-0" />
                  <div>
                    <span dangerouslySetInnerHTML={{ __html: content.gdprText.replace(
                      /Datenschutzerklärung/g, 
                      `<a href="${content.gdprLink}" target="_blank" class="text-primary hover:underline">Datenschutzerklärung</a>`
                    ) }} />
                    <span className="text-red-500 ml-1">*</span>
                  </div>
                </div>
              </Label>
            </div>
          </div>
          
          {errors.gdpr && (
            <p className="text-red-500 text-sm mt-2">{errors.gdpr}</p>
          )}
        </div>

        {errors.submit && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3">
            <p className="text-red-700 text-sm">{errors.submit}</p>
          </div>
        )}

        <Button
          type="submit"
          disabled={isSubmitting || !gdprConsent}
          className="w-full mt-6"
          data-testid="submit-button"
        >
          {isSubmitting ? 'Wird gesendet...' : content.buttonText}
        </Button>
      </form>

      <div className="mt-4 text-xs text-gray-500 text-center">
        <Shield className="h-3 w-3 inline mr-1" />
        Ihre Daten werden verschlüsselt übertragen und DSGVO-konform verarbeitet.
      </div>
    </div>
  );
}