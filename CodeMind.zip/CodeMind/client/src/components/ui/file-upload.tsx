import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { CloudUpload, File, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface FileUploadProps {
  onFileSelect: (file: File) => void;
  accept?: string;
  maxSize?: number; // in bytes
  className?: string;
  disabled?: boolean;
  'data-testid'?: string;
}

export function FileUpload({ 
  onFileSelect, 
  accept = "*/*", 
  maxSize = 5 * 1024 * 1024, // 5MB
  className,
  disabled = false,
  'data-testid': testId
}: FileUploadProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [error, setError] = useState<string>("");

  const onDrop = useCallback((acceptedFiles: File[], rejectedFiles: any[]) => {
    setError("");
    
    if (rejectedFiles.length > 0) {
      const rejection = rejectedFiles[0];
      if (rejection.errors?.[0]?.code === 'file-too-large') {
        setError(`Datei ist zu groß. Maximum: ${Math.round(maxSize / 1024 / 1024)}MB`);
      } else if (rejection.errors?.[0]?.code === 'file-invalid-type') {
        setError("Dateityp wird nicht unterstützt");
      } else {
        setError("Fehler beim Hochladen der Datei");
      }
      return;
    }

    if (acceptedFiles.length > 0) {
      const file = acceptedFiles[0];
      setSelectedFile(file);
      onFileSelect(file);
    }
  }, [onFileSelect, maxSize]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: accept ? { [accept]: [] } : undefined,
    maxSize,
    multiple: false,
    disabled
  });

  const removeFile = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedFile(null);
    setError("");
  };

  return (
    <div className={cn("w-full", className)}>
      <div
        {...getRootProps()}
        className={cn(
          "border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors",
          isDragActive ? "border-primary bg-primary/5" : "border-gray-300 hover:border-primary/50",
          disabled && "opacity-50 cursor-not-allowed",
          error && "border-red-300 bg-red-50"
        )}
        data-testid={testId}
      >
        <input {...getInputProps()} />
        
        {selectedFile ? (
          <div className="flex items-center justify-center space-x-2">
            <File className="h-6 w-6 text-gray-400" />
            <span className="text-sm text-gray-600 truncate max-w-48">
              {selectedFile.name}
            </span>
            <button
              onClick={removeFile}
              className="p-1 hover:bg-gray-200 rounded-full transition-colors"
              type="button"
            >
              <X className="h-4 w-4 text-gray-500" />
            </button>
          </div>
        ) : (
          <>
            <CloudUpload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
            {isDragActive ? (
              <p className="text-primary font-medium">Datei hier ablegen...</p>
            ) : (
              <>
                <p className="text-gray-600 mb-1">
                  Datei hierhin ziehen oder klicken zum Auswählen
                </p>
                <p className="text-xs text-gray-500">
                  Max. {Math.round(maxSize / 1024 / 1024)}MB
                </p>
              </>
            )}
          </>
        )}
      </div>
      
      {error && (
        <p className="text-red-500 text-sm mt-2">{error}</p>
      )}
    </div>
  );
}
