import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ScratchOffGame } from "@/components/modules/ScratchOffGame";
import { EnhancedQuiz } from "@/components/modules/EnhancedQuiz";
import { GDPRLeadForm } from "@/components/modules/GDPRLeadForm";
import { Smartphone, Sparkles, Brain, Trophy, Shield, QrCode } from "lucide-react";

export default function ModuleShowcase() {
  const [selectedModule, setSelectedModule] = useState("quiz");
  const [leadFormModal, setLeadFormModal] = useState(false);

  // Sample configurations for demonstrations
  const demoQuizConfig = {
    mode: "knowledge" as const,
    questions: [
      {
        question: "Welche Technologie revolutioniert die Industrie 4.0?",
        options: ["Cloud Computing", "Künstliche Intelligenz", "IoT Sensoren", "Alle drei"],
        correctAnswer: 3
      },
      {
        question: "Was ist der Hauptvorteil von digitalen Zwillingen?",
        options: ["Kosteneinsparung", "Predictive Maintenance", "Virtuelle Tests", "Alle oben"],
        correctAnswer: 3
      }
    ],
    results: {
      correct: "Exzellent! Sie kennen sich bestens mit Industrie 4.0 aus. Besuchen Sie unseren Stand für ein exklusives Whitepaper!",
      incorrect: "Noch Lernbedarf? Kein Problem! Unsere Experten am Stand helfen gerne weiter."
    },
    ctaText: "Experten-Gespräch vereinbaren",
    ctaAction: "lead_form" as const,
    ctaLink: ""
  };

  const demoPersonalityConfig = {
    mode: "personality" as const,
    questions: [
      {
        question: "Wie gehen Sie Entscheidungen an?",
        options: ["Daten-basiert", "Intuitiv", "Team-orientiert", "Risiko-bewusst"]
      },
      {
        question: "Was motiviert Sie am meisten?",
        options: ["Innovation", "Stabilität", "Wachstum", "Effizienz"]
      }
    ],
    results: {
      correct: "",
      incorrect: "",
      personality: {
        "A": "Analytiker: Sie sind datenorientiert und treffen durchdachte Entscheidungen. Perfekt für unsere Business Intelligence Lösungen!",
        "B": "Visionär: Sie vertrauen auf Intuition und innovative Ansätze. Entdecken Sie unsere zukunftsweisenden Technologien!",
        "C": "Teamplayer: Zusammenarbeit steht im Vordergrund. Unsere Collaboration-Tools sind ideal für Sie!",
        "D": "Stratege: Effizienz und kalkulierte Risiken sind Ihr Ding. Lernen Sie unsere Optimierungs-Software kennen!"
      }
    },
    ctaText: "Personalisiertes Angebot erhalten",
    ctaAction: "lead_form" as const,
    ctaLink: ""
  };

  const demoPrizeConfig = {
    title: "Premium Gewinnspiel",
    instructionText: "Rubbeln Sie das Feld frei und gewinnen Sie exklusive Preise! Bis zu 1000€ Beratungsgutschein möglich.",
    winProbability: 30,
    winConfig: {
      title: "🎉 Herzlichen Glückwunsch!",
      text: "Sie haben einen 500€ Beratungsgutschein gewonnen! Hinterlassen Sie Ihre Daten und wir melden uns binnen 24h.",
      action: "lead_form" as const,
      actionData: ""
    },
    loseConfig: {
      title: "Fast gewonnen!",
      text: "Schade, dieses Mal hat es nicht geklappt. Aber besuchen Sie gerne unseren Stand für ein kostenloses Fachgespräch!"
    }
  };

  const demoLeadFormConfig = {
    title: "Kontakt für Ihr kostenloses Beratungsgespräch",
    fields: [
      { name: "firstName", type: "text" as const, label: "Vorname", required: true, options: [] },
      { name: "lastName", type: "text" as const, label: "Nachname", required: true, options: [] },
      { name: "email", type: "email" as const, label: "E-Mail", required: true, options: [] },
      { name: "company", type: "text" as const, label: "Unternehmen", required: true, options: [] },
      { name: "position", type: "text" as const, label: "Position", required: false, options: [] },
      { name: "industry", type: "dropdown" as const, label: "Branche", required: false, 
        options: ["Automotive", "Maschinenbau", "IT/Software", "Pharma", "Logistik", "Sonstige"] }
    ],
    gdprText: "Ich stimme zu, dass meine Daten zur Bearbeitung meiner Anfrage gespeichert und verarbeitet werden. Weitere Informationen finden Sie in unserer Datenschutzerklärung.",
    gdprLink: "https://example.com/datenschutz",
    buttonText: "Beratungstermin anfragen",
    afterSubmitAction: "download" as const,
    afterSubmitData: "https://example.com/whitepaper.pdf"
  };

  const handleQuizComplete = (results: any) => {
    console.log("Quiz Results:", results);
    if (demoQuizConfig.ctaAction === 'lead_form' || demoPersonalityConfig.ctaAction === 'lead_form') {
      setLeadFormModal(true);
    }
  };

  const handlePrizeComplete = (won: boolean) => {
    console.log("Prize Game Result:", won);
    if (won) {
      setLeadFormModal(true);
    }
  };

  const handleLeadSubmit = (data: any) => {
    console.log("Lead Data:", data);
    alert("Demo: Lead erfolgreich erfasst! In der echten Anwendung würde dieser an Ihr CRM übertragen.");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        {/* Header Section */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="p-3 bg-primary/10 rounded-full">
              <Sparkles className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent">
              Messe-Moment Module Showcase
            </h1>
          </div>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto mb-8">
            Erleben Sie die Zukunft der Messe-Kommunikation: Interaktive Module, die aus passiven Besuchern 
            aktive Leads machen. Von intelligenten Quiz-Systemen bis zu DSGVO-konformen Lead-Formularen.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <Badge variant="secondary" className="px-4 py-2">
              <Brain className="h-4 w-4 mr-2" />
              KI-gestützte Personalisierung
            </Badge>
            <Badge variant="secondary" className="px-4 py-2">
              <Shield className="h-4 w-4 mr-2" />
              DSGVO-konform
            </Badge>
            <Badge variant="secondary" className="px-4 py-2">
              <Trophy className="h-4 w-4 mr-2" />
              Gamification-Elemente
            </Badge>
            <Badge variant="secondary" className="px-4 py-2">
              <QrCode className="h-4 w-4 mr-2" />
              QR-Code Integration
            </Badge>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Module Selector */}
          <div className="lg:col-span-1">
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Smartphone className="h-5 w-5" />
                  Live Demo Modules
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs value={selectedModule} onValueChange={setSelectedModule} orientation="vertical">
                  <TabsList className="grid w-full grid-cols-1 h-auto">
                    <TabsTrigger value="quiz" className="justify-start">
                      <Brain className="h-4 w-4 mr-2" />
                      Wissensquiz
                    </TabsTrigger>
                    <TabsTrigger value="personality" className="justify-start">
                      <Sparkles className="h-4 w-4 mr-2" />
                      Persönlichkeitstest
                    </TabsTrigger>
                    <TabsTrigger value="prize" className="justify-start">
                      <Trophy className="h-4 w-4 mr-2" />
                      Gewinnspiel
                    </TabsTrigger>
                    <TabsTrigger value="lead" className="justify-start">
                      <Shield className="h-4 w-4 mr-2" />
                      DSGVO-Formular
                    </TabsTrigger>
                  </TabsList>
                </Tabs>

                <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <h4 className="font-semibold mb-2">Verwendete Technologien:</h4>
                  <div className="space-y-1 text-sm text-gray-600 dark:text-gray-300">
                    <div>• React + TypeScript</div>
                    <div>• Canvas API für Rubbel-Effekte</div>
                    <div>• Zod Schema Validation</div>
                    <div>• PostgreSQL + Drizzle ORM</div>
                    <div>• Shadcn/ui Components</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Demo Area */}
          <div className="lg:col-span-2">
            <Card className="min-h-[600px]">
              <CardHeader>
                <CardTitle>
                  {selectedModule === 'quiz' && 'Intelligentes Wissensquiz'}
                  {selectedModule === 'personality' && 'Persönlichkeitstest'}
                  {selectedModule === 'prize' && 'Interaktives Gewinnspiel'}
                  {selectedModule === 'lead' && 'DSGVO-konformes Lead-Formular'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs value={selectedModule}>
                  <TabsContent value="quiz">
                    <div className="space-y-4">
                      <div className="p-4 bg-green-50 dark:bg-green-950 rounded-lg mb-6">
                        <h3 className="font-semibold text-green-800 dark:text-green-200 mb-2">
                          🎯 Wissensquiz Features
                        </h3>
                        <ul className="text-sm text-green-700 dark:text-green-300 space-y-1">
                          <li>• Multiple Choice mit bis zu 4 Antworten</li>
                          <li>• Intelligente Auswertung & personalisierte Ergebnisse</li>
                          <li>• Call-to-Action basiert auf Quiz-Performance</li>
                          <li>• Analytics zur Optimierung der Fragen</li>
                        </ul>
                      </div>
                      <EnhancedQuiz 
                        content={demoQuizConfig}
                        onQuizComplete={handleQuizComplete}
                        onLeadFormRequired={() => setLeadFormModal(true)}
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="personality">
                    <div className="space-y-4">
                      <div className="p-4 bg-purple-50 dark:bg-purple-950 rounded-lg mb-6">
                        <h3 className="font-semibold text-purple-800 dark:text-purple-200 mb-2">
                          ✨ Persönlichkeitstest Features
                        </h3>
                        <ul className="text-sm text-purple-700 dark:text-purple-300 space-y-1">
                          <li>• Keine "richtigen" Antworten - alle Optionen gleichwertig</li>
                          <li>• Personalisierte Produkt-Empfehlungen basiert auf Profil</li>
                          <li>• Höhere Engagement-Rate durch Gamification</li>
                          <li>• Segmentierung für personalisierte Follow-ups</li>
                        </ul>
                      </div>
                      <EnhancedQuiz 
                        content={demoPersonalityConfig}
                        onQuizComplete={handleQuizComplete}
                        onLeadFormRequired={() => setLeadFormModal(true)}
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="prize">
                    <div className="space-y-4">
                      <div className="p-4 bg-orange-50 dark:bg-orange-950 rounded-lg mb-6">
                        <h3 className="font-semibold text-orange-800 dark:text-orange-200 mb-2">
                          🎁 Gewinnspiel Features
                        </h3>
                        <ul className="text-sm text-orange-700 dark:text-orange-300 space-y-1">
                          <li>• Echter Canvas-basierter Rubbel-Effekt</li>
                          <li>• Konfigurierbare Gewinnwahrscheinlichkeit</li>
                          <li>• Sofortige Lead-Erfassung bei Gewinn</li>
                          <li>• Mobile-optimiert für Touch-Geräte</li>
                        </ul>
                      </div>
                      <ScratchOffGame 
                        content={demoPrizeConfig}
                        onGameComplete={handlePrizeComplete}
                        onLeadFormRequired={() => setLeadFormModal(true)}
                      />
                    </div>
                  </TabsContent>

                  <TabsContent value="lead">
                    <div className="space-y-4">
                      <div className="p-4 bg-blue-50 dark:bg-blue-950 rounded-lg mb-6">
                        <h3 className="font-semibold text-blue-800 dark:text-blue-200 mb-2">
                          🛡️ DSGVO-Formular Features
                        </h3>
                        <ul className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
                          <li>• Vollständige DSGVO-Compliance mit Consent-Management</li>
                          <li>• Flexible Feldtypen: Text, E-Mail, Telefon, Dropdown</li>
                          <li>• Client-side & Server-side Validierung</li>
                          <li>• Automatische CRM-Integration nach Submission</li>
                        </ul>
                      </div>
                      <GDPRLeadForm 
                        content={demoLeadFormConfig}
                        campaignId="demo-showcase"
                        onSubmitSuccess={handleLeadSubmit}
                      />
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            {/* ROI Section */}
            <Card className="mt-8">
              <CardHeader>
                <CardTitle>📈 Messbare Erfolge mit Messe-Moment</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                    <div className="text-3xl font-bold text-green-600">+340%</div>
                    <div className="text-sm text-green-700 dark:text-green-300">Lead-Generierung</div>
                  </div>
                  <div className="text-center p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                    <div className="text-3xl font-bold text-blue-600">78%</div>
                    <div className="text-sm text-blue-700 dark:text-blue-300">Engagement-Rate</div>
                  </div>
                  <div className="text-center p-4 bg-purple-50 dark:bg-purple-950 rounded-lg">
                    <div className="text-3xl font-bold text-purple-600">92%</div>
                    <div className="text-sm text-purple-700 dark:text-purple-300">DSGVO-Compliance</div>
                  </div>
                </div>
                
                <div className="mt-6 text-center">
                  <Button size="lg" className="px-8">
                    <QrCode className="h-5 w-5 mr-2" />
                    Ihre Kampagne jetzt erstellen
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Lead Form Modal */}
        {leadFormModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold">Kontakt für Gewinn-Einlösung</h3>
                  <Button variant="ghost" size="sm" onClick={() => setLeadFormModal(false)}>
                    ✕
                  </Button>
                </div>
                <GDPRLeadForm 
                  content={demoLeadFormConfig}
                  campaignId="demo-modal"
                  onSubmitSuccess={(data) => {
                    handleLeadSubmit(data);
                    setLeadFormModal(false);
                  }}
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}