import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { QrCode, Users, BarChart3, Target, ArrowRight } from "lucide-react";

export default function AuthPage() {
  const [, setLocation] = useLocation();
  const { user, loginMutation, registerMutation } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("login");

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      setLocation("/");
    }
  }, [user, setLocation]);

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    try {
      await loginMutation.mutateAsync({
        username: formData.get("email") as string,
        password: formData.get("password") as string,
      });
      setLocation("/");
    } catch (error) {
      // Error is handled by the mutation's onError
    }
  };

  const handleRegister = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const password = formData.get("password") as string;
    if (password.length < 8) {
      toast({
        title: "Fehler",
        description: "Das Passwort muss mindestens 8 Zeichen lang sein.",
        variant: "destructive",
      });
      return;
    }

    try {
      await registerMutation.mutateAsync({
        email: formData.get("email") as string,
        password: password,
        firstName: formData.get("firstName") as string,
        lastName: formData.get("lastName") as string,
        companyName: formData.get("company") as string,
      });
      setLocation("/");
    } catch (error) {
      // Error is handled by the mutation's onError
    }
  };

  const handleForgotPassword = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    toast({
      title: "Reset-Link gesendet",
      description: "Wir haben Ihnen einen Link zum Zurücksetzen Ihres Passworts per E-Mail gesendet.",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-white">
      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8 items-center max-w-6xl mx-auto">
          {/* Hero Section */}
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <QrCode className="h-8 w-8 text-primary" />
                <span className="text-2xl font-bold text-primary">Messe-Moment</span>
              </div>
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight">
                Machen Sie Ihre Messe-Werbeartikel zu{" "}
                <span className="text-primary">messbaren Marketing-Kampagnen</span>
              </h1>
              <p className="text-xl text-gray-600">
                Verwandeln Sie jeden Kugelschreiber in eine interaktive Marketing-Kampagne. 
                Generieren Sie qualifizierte Leads und messen Sie den ROI Ihres Messe-Marketings.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-white rounded-lg p-4 shadow-sm border">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center mb-3">
                  <QrCode className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-1">QR-Code auf Werbeartikel</h3>
                <p className="text-sm text-gray-600">Einfache Integration in bestehende Materialien</p>
              </div>
              
              <div className="bg-white rounded-lg p-4 shadow-sm border">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center mb-3">
                  <Target className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-1">Mobile Kampagne erstellen</h3>
                <p className="text-sm text-gray-600">Drag & Drop Editor für interaktive Inhalte</p>
              </div>
              
              <div className="bg-white rounded-lg p-4 shadow-sm border">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center mb-3">
                  <BarChart3 className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-1">Leads & Analytics erfassen</h3>
                <p className="text-sm text-gray-600">Messbare Ergebnisse und ROI-Tracking</p>
              </div>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-sm border">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">QR-Code + Digitale Kampagne</h3>
                  <p className="text-gray-600">Einfache Verbindung zwischen physischen und digitalen Touchpoints</p>
                </div>
                <div className="w-24 h-24 bg-gray-100 rounded-lg flex items-center justify-center">
                  <QrCode className="h-12 w-12 text-gray-400" />
                </div>
              </div>
            </div>
          </div>

          {/* Auth Forms */}
          <div className="w-full max-w-md mx-auto">
            <Card>
              <CardHeader className="text-center space-y-4">
                <div className="flex items-center justify-center space-x-2">
                  <QrCode className="h-6 w-6 text-primary" />
                  <span className="text-xl font-bold text-primary">Messe-Moment</span>
                </div>
              </CardHeader>
              
              <CardContent>
                <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="login" data-testid="tab-login">Anmelden</TabsTrigger>
                    <TabsTrigger value="register" data-testid="tab-register">Registrieren</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="login" className="space-y-4">
                    <div className="text-center space-y-2">
                      <CardTitle>Bei Ihrem Konto anmelden</CardTitle>
                      <CardDescription>
                        Oder{" "}
                        <button 
                          onClick={() => setActiveTab("register")}
                          className="text-primary hover:text-primary/80 font-medium"
                          data-testid="link-to-register"
                        >
                          erstellen Sie ein kostenloses Konto
                        </button>
                      </CardDescription>
                    </div>
                    
                    <form onSubmit={handleLogin} className="space-y-4" data-testid="form-login">
                      <div className="space-y-2">
                        <Label htmlFor="login-email">E-Mail-Adresse</Label>
                        <Input
                          id="login-email"
                          name="email"
                          type="email"
                          placeholder="ihre.email@firma.de"
                          required
                          data-testid="input-login-email"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="login-password">Passwort</Label>
                        <Input
                          id="login-password"
                          name="password"
                          type="password"
                          placeholder="••••••••"
                          required
                          data-testid="input-login-password"
                        />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Checkbox id="remember" />
                          <Label htmlFor="remember" className="text-sm">Angemeldet bleiben</Label>
                        </div>
                        <button 
                          type="button"
                          onClick={() => setActiveTab("forgot")}
                          className="text-sm text-primary hover:text-primary/80"
                          data-testid="link-forgot-password"
                        >
                          Passwort vergessen?
                        </button>
                      </div>
                      
                      <Button 
                        type="submit" 
                        className="w-full" 
                        disabled={loginMutation.isPending}
                        data-testid="button-login"
                      >
                        {loginMutation.isPending ? "Wird angemeldet..." : "Anmelden"}
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </form>
                  </TabsContent>
                  
                  <TabsContent value="register" className="space-y-4">
                    <div className="text-center space-y-2">
                      <CardTitle>Kostenloses Konto erstellen</CardTitle>
                      <CardDescription>
                        Oder{" "}
                        <button 
                          onClick={() => setActiveTab("login")}
                          className="text-primary hover:text-primary/80 font-medium"
                          data-testid="link-to-login"
                        >
                          melden Sie sich bei Ihrem Konto an
                        </button>
                      </CardDescription>
                    </div>
                    
                    <form onSubmit={handleRegister} className="space-y-4" data-testid="form-register">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="register-firstname">Vorname</Label>
                          <Input
                            id="register-firstname"
                            name="firstName"
                            type="text"
                            placeholder="Max"
                            required
                            data-testid="input-register-firstname"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="register-lastname">Nachname</Label>
                          <Input
                            id="register-lastname"
                            name="lastName"
                            type="text"
                            placeholder="Mustermann"
                            required
                            data-testid="input-register-lastname"
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="register-company">Firma</Label>
                        <Input
                          id="register-company"
                          name="company"
                          type="text"
                          placeholder="Mustermann GmbH"
                          required
                          data-testid="input-register-company"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="register-email">E-Mail-Adresse</Label>
                        <Input
                          id="register-email"
                          name="email"
                          type="email"
                          placeholder="max@mustermann-gmbh.de"
                          required
                          data-testid="input-register-email"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="register-password">Passwort</Label>
                        <Input
                          id="register-password"
                          name="password"
                          type="password"
                          placeholder="••••••••"
                          required
                          data-testid="input-register-password"
                        />
                        <p className="text-xs text-gray-500">Mindestens 8 Zeichen</p>
                      </div>
                      
                      <div className="flex items-start space-x-2">
                        <Checkbox id="terms" required />
                        <Label htmlFor="terms" className="text-sm leading-5">
                          Ich stimme den{" "}
                          <a href="#" className="text-primary hover:text-primary/80">Nutzungsbedingungen</a>{" "}
                          und der{" "}
                          <a href="#" className="text-primary hover:text-primary/80">Datenschutzerklärung</a>{" "}
                          zu.
                        </Label>
                      </div>
                      
                      <Button 
                        type="submit" 
                        className="w-full" 
                        disabled={registerMutation.isPending}
                        data-testid="button-register"
                      >
                        {registerMutation.isPending ? "Konto wird erstellt..." : "Kostenloses Konto erstellen"}
                        <Users className="ml-2 h-4 w-4" />
                      </Button>
                    </form>
                  </TabsContent>
                  
                  <TabsContent value="forgot" className="space-y-4">
                    <div className="text-center space-y-2">
                      <CardTitle>Passwort zurücksetzen</CardTitle>
                      <CardDescription>
                        Geben Sie Ihre E-Mail-Adresse ein und wir senden Ihnen einen Link zum Zurücksetzen.
                      </CardDescription>
                    </div>
                    
                    <form onSubmit={handleForgotPassword} className="space-y-4" data-testid="form-forgot-password">
                      <div className="space-y-2">
                        <Label htmlFor="forgot-email">E-Mail-Adresse</Label>
                        <Input
                          id="forgot-email"
                          name="email"
                          type="email"
                          placeholder="ihre.email@firma.de"
                          required
                          data-testid="input-forgot-email"
                        />
                      </div>
                      
                      <Button type="submit" className="w-full" data-testid="button-forgot-password">
                        Reset-Link senden
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                      
                      <div className="text-center">
                        <button 
                          type="button"
                          onClick={() => setActiveTab("login")}
                          className="text-primary hover:text-primary/80 font-medium"
                          data-testid="link-back-to-login"
                        >
                          ← Zurück zur Anmeldung
                        </button>
                      </div>
                    </form>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
