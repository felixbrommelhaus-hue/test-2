import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";
import { 
  QrCode, 
  BarChart3, 
  Users, 
  TrendingUp, 
  Plus, 
  Eye,
  Edit,
  Trash2,
  Download,
  Copy,
  Bell,
  ChevronDown
} from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { formatDistanceToNow } from "date-fns";
import { de } from "date-fns/locale";

interface DashboardStats {
  activeCampaigns: number;
  totalScans: number;
  totalLeads: number;
  conversionRate: number;
}

interface Campaign {
  id: string;
  name: string;
  description: string | null;
  isPublished: boolean;
  publicUrlSlug: string | null;
  createdAt: string;
  scans: number;
  leads: number;
  conversion: number;
}

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const [, setLocation] = useLocation();

  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: campaigns, isLoading: campaignsLoading } = useQuery<Campaign[]>({
    queryKey: ["/api/campaigns"],
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const handleCreateCampaign = () => {
    setLocation("/campaign-builder");
  };

  const getStatusBadge = (campaign: Campaign) => {
    if (campaign.isPublished) {
      return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
        <div className="w-2 h-2 bg-green-500 rounded-full mr-1" />
        Aktiv
      </Badge>;
    }
    return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
      <div className="w-2 h-2 bg-yellow-500 rounded-full mr-1" />
      Entwurf
    </Badge>;
  };

  const downloadQR = async (campaignId: string, format: 'svg' | 'png') => {
    try {
      const response = await fetch(`/api/campaigns/${campaignId}/qr?format=${format}`, {
        credentials: 'include'
      });
      
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `qr-code.${format}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }
    } catch (error) {
      console.error('Error downloading QR code:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <div className="flex items-center space-x-2 text-2xl font-bold text-primary mr-8">
                <QrCode className="h-8 w-8" />
                <span>Messe-Moment</span>
              </div>
              <nav className="hidden md:flex space-x-8">
                <a href="#" className="text-primary font-medium border-b-2 border-primary pb-4">
                  Kampagnen
                </a>
                <a href="#" className="text-gray-500 hover:text-gray-700 pb-4">
                  Analytics
                </a>
                <a href="#" className="text-gray-500 hover:text-gray-700 pb-4">
                  Integrationen
                </a>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" data-testid="button-notifications">
                <Bell className="h-5 w-5" />
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-2" data-testid="button-user-menu">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {user?.firstName?.[0]?.toUpperCase() || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <span className="font-medium hidden sm:block">{user?.firstName}</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem data-testid="menu-profile">
                    Profil bearbeiten
                  </DropdownMenuItem>
                  <DropdownMenuItem data-testid="menu-settings">
                    Einstellungen
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} data-testid="menu-logout">
                    Abmelden
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <BarChart3 className="h-6 w-6 text-primary" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Aktive Kampagnen</p>
                  <p className="text-2xl font-bold text-gray-900" data-testid="stat-active-campaigns">
                    {statsLoading ? "..." : stats?.activeCampaigns || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <QrCode className="h-6 w-6 text-green-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">QR-Code Scans</p>
                  <p className="text-2xl font-bold text-gray-900" data-testid="stat-total-scans">
                    {statsLoading ? "..." : stats?.totalScans || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Generierte Leads</p>
                  <p className="text-2xl font-bold text-gray-900" data-testid="stat-total-leads">
                    {statsLoading ? "..." : stats?.totalLeads || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-yellow-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Conversion Rate</p>
                  <p className="text-2xl font-bold text-gray-900" data-testid="stat-conversion-rate">
                    {statsLoading ? "..." : `${stats?.conversionRate || 0}%`}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Campaign Management Section */}
        <Card>
          <CardHeader className="border-b border-gray-200">
            <div className="flex justify-between items-center">
              <CardTitle className="text-xl font-semibold text-gray-900">
                Meine Kampagnen
              </CardTitle>
              <Button onClick={handleCreateCampaign} data-testid="button-create-campaign">
                <Plus className="mr-2 h-4 w-4" />
                Neue Kampagne erstellen
              </Button>
            </div>
          </CardHeader>

          <CardContent className="p-6">
            {campaignsLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                <p className="text-gray-500 mt-4">Kampagnen werden geladen...</p>
              </div>
            ) : campaigns && campaigns.length > 0 ? (
              <div className="space-y-4">
                {campaigns.map((campaign) => (
                  <div
                    key={campaign.id}
                    className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow"
                    data-testid={`campaign-card-${campaign.id}`}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center mb-2">
                          <h3 className="text-lg font-semibold text-gray-900 mr-3" data-testid={`campaign-name-${campaign.id}`}>
                            {campaign.name}
                          </h3>
                          {getStatusBadge(campaign)}
                        </div>
                        {campaign.description && (
                          <p className="text-gray-600 mb-4" data-testid={`campaign-description-${campaign.id}`}>
                            {campaign.description}
                          </p>
                        )}
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <p className="text-gray-500">Erstellt am</p>
                            <p className="font-medium" data-testid={`campaign-created-${campaign.id}`}>
                              {formatDistanceToNow(new Date(campaign.createdAt), { 
                                addSuffix: true, 
                                locale: de 
                              })}
                            </p>
                          </div>
                          <div>
                            <p className="text-gray-500">QR-Scans</p>
                            <p className="font-medium text-primary" data-testid={`campaign-scans-${campaign.id}`}>
                              {campaign.scans || 0}
                            </p>
                          </div>
                          <div>
                            <p className="text-gray-500">Leads</p>
                            <p className="font-medium text-green-600" data-testid={`campaign-leads-${campaign.id}`}>
                              {campaign.leads || 0}
                            </p>
                          </div>
                          <div>
                            <p className="text-gray-500">Conversion</p>
                            <p className="font-medium" data-testid={`campaign-conversion-${campaign.id}`}>
                              {campaign.conversion || 0}%
                            </p>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2 ml-6">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          title="Analytics"
                          data-testid={`button-analytics-${campaign.id}`}
                        >
                          <BarChart3 className="h-4 w-4" />
                        </Button>
                        
                        {campaign.isPublished && (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                title="QR-Code herunterladen"
                                data-testid={`button-qr-download-${campaign.id}`}
                              >
                                <QrCode className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent>
                              <DropdownMenuItem onClick={() => downloadQR(campaign.id, 'png')}>
                                <Download className="mr-2 h-4 w-4" />
                                PNG herunterladen
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => downloadQR(campaign.id, 'svg')}>
                                <Download className="mr-2 h-4 w-4" />
                                SVG herunterladen
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <Copy className="mr-2 h-4 w-4" />
                                URL kopieren
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        )}
                        
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          title="Bearbeiten"
                          onClick={() => setLocation(`/campaign-builder?id=${campaign.id}`)}
                          data-testid={`button-edit-${campaign.id}`}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          title="Löschen"
                          className="text-red-500 hover:text-red-700"
                          data-testid={`button-delete-${campaign.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <QrCode className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Noch keine Kampagnen
                </h3>
                <p className="text-gray-500 mb-6">
                  Erstellen Sie Ihre erste interaktive Marketing-Kampagne
                </p>
                <Button onClick={handleCreateCampaign} data-testid="button-create-first-campaign">
                  <Plus className="mr-2 h-4 w-4" />
                  Erste Kampagne erstellen
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
