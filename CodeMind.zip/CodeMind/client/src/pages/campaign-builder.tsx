import { useState, useCallback } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { FileUpload } from "@/components/ui/file-upload";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  ArrowLeft,
  QrCode,
  Eye,
  Rocket,
  Type,
  AlignLeft,
  HelpCircle,
  UserPlus,
  Gift,
  Smartphone,
  Copy,
  Download,
  Save
} from "lucide-react";

interface CampaignModule {
  id: string;
  moduleType: string;
  content: any;
  position: number;
}

interface ModuleType {
  type: string;
  name: string;
  description: string;
  icon: any;
  color: string;
}

const moduleTypes: ModuleType[] = [
  {
    type: 'header',
    name: 'Header',
    description: 'Logo und Überschrift für Ihre Kampagne',
    icon: Type,
    color: 'blue'
  },
  {
    type: 'text',
    name: 'Text',
    description: 'Fließtext für Beschreibungen und Informationen',
    icon: AlignLeft,
    color: 'gray'
  },
  {
    type: 'quiz',
    name: 'Quiz',
    description: 'Interaktives Quiz mit bis zu 4 Antwortmöglichkeiten',
    icon: HelpCircle,
    color: 'green'
  },
  {
    type: 'lead_form',
    name: 'Lead-Formular',
    description: 'DSGVO-konformes Formular zur Lead-Generierung',
    icon: UserPlus,
    color: 'purple'
  },
  {
    type: 'prize',
    name: 'Gewinnspiel',
    description: 'Instant-Win Gewinnspiel mit konfigurierbaren Gewinnchancen',
    icon: Gift,
    color: 'yellow'
  }
];

export default function CampaignBuilder() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [campaignName, setCampaignName] = useState("Neue Kampagne");
  const [campaignDescription, setCampaignDescription] = useState("");
  const [modules, setModules] = useState<CampaignModule[]>([]);
  const [selectedModule, setSelectedModule] = useState<CampaignModule | null>(null);
  const [primaryColor, setPrimaryColor] = useState("#2563eb");

  const createCampaignMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/campaigns", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Kampagne erstellt",
        description: "Ihre Kampagne wurde erfolgreich erstellt.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/campaigns"] });
      setLocation("/");
    },
    onError: (error: Error) => {
      toast({
        title: "Fehler",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSaveCampaign = () => {
    createCampaignMutation.mutate({
      name: campaignName,
      description: campaignDescription,
      isPublished: false
    });
  };

  const handlePublishCampaign = () => {
    createCampaignMutation.mutate({
      name: campaignName,
      description: campaignDescription,
      isPublished: true
    });
  };

  const addModule = useCallback((moduleType: string) => {
    const newModule: CampaignModule = {
      id: `module-${Date.now()}`,
      moduleType,
      content: getDefaultContent(moduleType),
      position: modules.length
    };
    setModules([...modules, newModule]);
  }, [modules]);

  const updateModule = useCallback((moduleId: string, content: any) => {
    setModules(modules.map(module => 
      module.id === moduleId ? { ...module, content } : module
    ));
  }, [modules]);

  const removeModule = useCallback((moduleId: string) => {
    setModules(modules.filter(module => module.id !== moduleId));
    if (selectedModule?.id === moduleId) {
      setSelectedModule(null);
    }
  }, [modules, selectedModule]);

  const getDefaultContent = (moduleType: string) => {
    switch (moduleType) {
      case 'header':
        return { title: 'Willkommen!', subtitle: 'Ihre Kampagne' };
      case 'text':
        return { text: 'Fügen Sie hier Ihren Text ein...' };
      case 'quiz':
        return { 
          question: 'Ihre Quiz-Frage?', 
          options: ['Option A', 'Option B', 'Option C', 'Option D'],
          correctAnswer: 0
        };
      case 'lead_form':
        return { 
          title: 'Kontakt für weitere Informationen',
          buttonText: 'Absenden',
          fields: ['firstName', 'lastName', 'email']
        };
      case 'prize':
        return { 
          title: 'Gewinnspiel',
          buttonText: 'Jetzt teilnehmen',
          winChance: 10
        };
      default:
        return {};
    }
  };

  const renderModulePreview = (module: CampaignModule) => {
    const isSelected = selectedModule?.id === module.id;
    const borderColor = isSelected ? 'border-primary' : 'border-gray-200';
    
    switch (module.moduleType) {
      case 'header':
        return (
          <div 
            className={`border-2 ${borderColor} rounded-lg p-4 bg-blue-50 cursor-pointer`}
            onClick={() => setSelectedModule(module)}
            data-testid={`module-preview-${module.id}`}
          >
            <div className="text-center">
              <div className="w-12 h-12 bg-gray-200 rounded mx-auto mb-3 flex items-center justify-center">
                <Type className="h-6 w-6 text-gray-400" />
              </div>
              <h3 className="text-lg font-bold text-gray-900">{module.content.title}</h3>
              {module.content.subtitle && (
                <p className="text-sm text-gray-600 mt-1">{module.content.subtitle}</p>
              )}
            </div>
          </div>
        );

      case 'text':
        return (
          <div 
            className={`border-2 ${borderColor} rounded-lg p-4 bg-gray-50 cursor-pointer`}
            onClick={() => setSelectedModule(module)}
            data-testid={`module-preview-${module.id}`}
          >
            <p className="text-gray-700">{module.content.text}</p>
          </div>
        );

      case 'quiz':
        return (
          <div 
            className={`border-2 ${borderColor} rounded-lg p-4 bg-green-50 cursor-pointer`}
            onClick={() => setSelectedModule(module)}
            data-testid={`module-preview-${module.id}`}
          >
            <h4 className="font-semibold text-gray-900 mb-3">{module.content.question}</h4>
            <div className="space-y-2">
              {module.content.options.map((option: string, index: number) => (
                <button
                  key={index}
                  className="w-full text-left p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors text-sm"
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        );

      case 'lead_form':
        return (
          <div 
            className={`border-2 ${borderColor} rounded-lg p-4 bg-purple-50 cursor-pointer`}
            onClick={() => setSelectedModule(module)}
            data-testid={`module-preview-${module.id}`}
          >
            <h4 className="font-semibold text-gray-900 mb-3">{module.content.title}</h4>
            <div className="space-y-3">
              <input type="text" placeholder="Vorname" className="w-full p-3 border border-gray-200 rounded-lg text-sm" disabled />
              <input type="text" placeholder="Nachname" className="w-full p-3 border border-gray-200 rounded-lg text-sm" disabled />
              <input type="email" placeholder="E-Mail" className="w-full p-3 border border-gray-200 rounded-lg text-sm" disabled />
              <div className="flex items-start space-x-2">
                <input type="checkbox" className="mt-1" disabled />
                <span className="text-xs text-gray-600">
                  Ich bin mit der Verarbeitung meiner Daten einverstanden (DSGVO)
                </span>
              </div>
              <button className="w-full bg-primary text-white p-3 rounded-lg font-medium text-sm">
                {module.content.buttonText}
              </button>
            </div>
          </div>
        );

      case 'prize':
        return (
          <div 
            className={`border-2 ${borderColor} rounded-lg p-4 bg-yellow-50 cursor-pointer`}
            onClick={() => setSelectedModule(module)}
            data-testid={`module-preview-${module.id}`}
          >
            <div className="text-center">
              <h4 className="font-semibold text-gray-900 mb-3">{module.content.title}</h4>
              <button className="bg-yellow-500 text-white px-6 py-3 rounded-lg font-medium">
                {module.content.buttonText}
              </button>
            </div>
          </div>
        );

      default:
        return (
          <div className="border-2 border-gray-200 rounded-lg p-4 bg-gray-50">
            <p className="text-gray-500">Unknown module type: {module.moduleType}</p>
          </div>
        );
    }
  };

  const renderPropertiesPanel = () => {
    if (!selectedModule) {
      return (
        <div className="text-center py-8">
          <QrCode className="h-12 w-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">Wählen Sie ein Modul aus, um dessen Eigenschaften zu bearbeiten.</p>
        </div>
      );
    }

    const updateContent = (field: string, value: any) => {
      updateModule(selectedModule.id, {
        ...selectedModule.content,
        [field]: value
      });
    };

    switch (selectedModule.moduleType) {
      case 'header':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="header-title">Titel</Label>
              <Input
                id="header-title"
                value={selectedModule.content.title || ''}
                onChange={(e) => updateContent('title', e.target.value)}
                data-testid="input-header-title"
              />
            </div>
            <div>
              <Label htmlFor="header-subtitle">Untertitel</Label>
              <Input
                id="header-subtitle"
                value={selectedModule.content.subtitle || ''}
                onChange={(e) => updateContent('subtitle', e.target.value)}
                data-testid="input-header-subtitle"
              />
            </div>
          </div>
        );

      case 'text':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="text-content">Text</Label>
              <Textarea
                id="text-content"
                value={selectedModule.content.text || ''}
                onChange={(e) => updateContent('text', e.target.value)}
                rows={4}
                data-testid="textarea-text-content"
              />
            </div>
          </div>
        );

      case 'quiz':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="quiz-question">Frage</Label>
              <Input
                id="quiz-question"
                value={selectedModule.content.question || ''}
                onChange={(e) => updateContent('question', e.target.value)}
                data-testid="input-quiz-question"
              />
            </div>
            {selectedModule.content.options?.map((option: string, index: number) => (
              <div key={index}>
                <Label htmlFor={`quiz-option-${index}`}>Option {index + 1}</Label>
                <Input
                  id={`quiz-option-${index}`}
                  value={option}
                  onChange={(e) => {
                    const newOptions = [...selectedModule.content.options];
                    newOptions[index] = e.target.value;
                    updateContent('options', newOptions);
                  }}
                  data-testid={`input-quiz-option-${index}`}
                />
              </div>
            ))}
          </div>
        );

      case 'lead_form':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="form-title">Titel</Label>
              <Input
                id="form-title"
                value={selectedModule.content.title || ''}
                onChange={(e) => updateContent('title', e.target.value)}
                data-testid="input-form-title"
              />
            </div>
            <div>
              <Label htmlFor="form-button">Button Text</Label>
              <Input
                id="form-button"
                value={selectedModule.content.buttonText || ''}
                onChange={(e) => updateContent('buttonText', e.target.value)}
                data-testid="input-form-button"
              />
            </div>
          </div>
        );

      case 'prize':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="prize-title">Titel</Label>
              <Input
                id="prize-title"
                value={selectedModule.content.title || ''}
                onChange={(e) => updateContent('title', e.target.value)}
                data-testid="input-prize-title"
              />
            </div>
            <div>
              <Label htmlFor="prize-button">Button Text</Label>
              <Input
                id="prize-button"
                value={selectedModule.content.buttonText || ''}
                onChange={(e) => updateContent('buttonText', e.target.value)}
                data-testid="input-prize-button"
              />
            </div>
            <div>
              <Label htmlFor="prize-chance">Gewinnchance (%)</Label>
              <Input
                id="prize-chance"
                type="number"
                min="1"
                max="100"
                value={selectedModule.content.winChance || 10}
                onChange={(e) => updateContent('winChance', parseInt(e.target.value))}
                data-testid="input-prize-chance"
              />
            </div>
          </div>
        );

      default:
        return <div>No properties available for this module type.</div>;
    }
  };

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 flex-shrink-0">
        <div className="px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setLocation("/")}
                className="mr-4"
                data-testid="button-back"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div className="flex items-center space-x-2 text-xl font-bold text-primary mr-6">
                <QrCode className="h-6 w-6" />
                <span>Messe-Moment</span>
              </div>
              <div>
                <Input
                  value={campaignName}
                  onChange={(e) => setCampaignName(e.target.value)}
                  className="text-lg font-semibold bg-transparent border-none focus:ring-2 focus:ring-primary/20 px-2 py-1"
                  data-testid="input-campaign-name"
                />
                <p className="text-sm text-gray-500">Entwurf • Zuletzt bearbeitet gerade eben</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" data-testid="button-preview">
                <Eye className="mr-2 h-4 w-4" />
                Vorschau
              </Button>
              <Button onClick={handleSaveCampaign} variant="outline" data-testid="button-save">
                <Save className="mr-2 h-4 w-4" />
                Speichern
              </Button>
              <Button 
                onClick={handlePublishCampaign} 
                disabled={createCampaignMutation.isPending}
                data-testid="button-publish"
              >
                <Rocket className="mr-2 h-4 w-4" />
                {createCampaignMutation.isPending ? "Wird veröffentlicht..." : "Veröffentlichen"}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Module Library */}
        <div className="w-80 bg-white border-r border-gray-200 flex-shrink-0 overflow-y-auto">
          <div className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Module</h3>
            <div className="space-y-3">
              {moduleTypes.map((moduleType) => {
                const Icon = moduleType.icon;
                return (
                  <Card
                    key={moduleType.type}
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => addModule(moduleType.type)}
                    data-testid={`module-type-${moduleType.type}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center mb-2">
                        <div className={`w-8 h-8 bg-${moduleType.color}-100 rounded-lg flex items-center justify-center mr-3`}>
                          <Icon className={`h-4 w-4 text-${moduleType.color}-600`} />
                        </div>
                        <h4 className="font-medium text-gray-900">{moduleType.name}</h4>
                      </div>
                      <p className="text-sm text-gray-600">{moduleType.description}</p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            <div className="mt-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Kampagnen-Einstellungen</h3>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="campaign-description">Beschreibung</Label>
                  <Textarea
                    id="campaign-description"
                    value={campaignDescription}
                    onChange={(e) => setCampaignDescription(e.target.value)}
                    placeholder="Beschreibung Ihrer Kampagne..."
                    data-testid="textarea-campaign-description"
                  />
                </div>
                <div>
                  <Label htmlFor="logo-upload">Firmen-Logo</Label>
                  <FileUpload
                    accept="image/*"
                    onFileSelect={(file) => console.log('Logo selected:', file)}
                    data-testid="file-upload-logo"
                  />
                </div>
                <div>
                  <Label htmlFor="primary-color">Primärfarbe</Label>
                  <Input
                    id="primary-color"
                    type="color"
                    value={primaryColor}
                    onChange={(e) => setPrimaryColor(e.target.value)}
                    className="w-full h-10"
                    data-testid="input-primary-color"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Phone Preview */}
        <div className="flex-1 flex items-center justify-center p-8 bg-gray-100">
          <div className="relative">
            <div className="w-80 h-[600px] bg-black rounded-[2.5rem] p-2 shadow-2xl">
              <div className="w-full h-full bg-white rounded-[2rem] overflow-hidden relative">
                {/* Phone Status Bar */}
                <div className="bg-gray-900 text-white text-xs flex justify-between items-center px-6 py-2">
                  <span>9:41</span>
                  <div className="flex items-center space-x-1">
                    <div className="w-4 h-2 bg-white rounded-sm"></div>
                    <div className="w-3 h-3 border border-white rounded-full"></div>
                    <div className="w-6 h-3 border border-white rounded-sm"></div>
                  </div>
                </div>

                {/* Campaign Preview Content */}
                <div className="h-full overflow-y-auto pb-20 p-6" data-testid="phone-preview">
                  {modules.length === 0 ? (
                    <div className="text-center py-12">
                      <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                        <Smartphone className="h-8 w-8 text-primary" />
                      </div>
                      <h2 className="text-xl font-bold text-gray-900 mb-2">Willkommen!</h2>
                      <p className="text-gray-600">Ziehen Sie Module aus der linken Leiste hierher, um Ihre Kampagne zu erstellen.</p>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {modules.map((module) => (
                        <div key={module.id} className="relative group">
                          {renderModulePreview(module)}
                          <Button
                            variant="destructive"
                            size="sm"
                            className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => removeModule(module.id)}
                            data-testid={`button-remove-module-${module.id}`}
                          >
                            ×
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
            <div className="text-center mt-4">
              <p className="text-sm text-gray-600">Live-Vorschau Ihrer Kampagne</p>
            </div>
          </div>
        </div>

        {/* Properties Panel */}
        <div className="w-80 bg-white border-l border-gray-200 flex-shrink-0 overflow-y-auto">
          <div className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Eigenschaften</h3>
            
            <div className="mb-8">
              {renderPropertiesPanel()}
            </div>

            {/* QR Code Generation Section */}
            <div className="border-t border-gray-200 pt-6">
              <h4 className="font-semibold text-gray-900 mb-4">QR-Code & Veröffentlichung</h4>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="campaign-url">Kampagnen-URL</Label>
                  <div className="flex">
                    <Input
                      id="campaign-url"
                      readOnly
                      value="app.messe-moment.de/c/preview"
                      className="flex-1 bg-gray-50 text-sm"
                      data-testid="input-campaign-url"
                    />
                    <Button variant="outline" size="icon" className="ml-2" data-testid="button-copy-url">
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="text-center">
                  <div className="w-32 h-32 bg-gray-100 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <QrCode className="h-16 w-16 text-gray-400" />
                  </div>
                  <p className="text-sm text-gray-600 mb-3">QR-Code Vorschau</p>
                  <div className="flex space-x-2">
                    <Button variant="outline" className="flex-1 text-sm" data-testid="button-download-png">
                      <Download className="mr-1 h-3 w-3" />
                      PNG
                    </Button>
                    <Button variant="outline" className="flex-1 text-sm" data-testid="button-download-svg">
                      <Download className="mr-1 h-3 w-3" />
                      SVG
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
