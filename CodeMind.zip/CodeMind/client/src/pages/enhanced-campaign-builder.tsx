import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Plus, Smartphone, Eye, Save, Settings, Edit, Trash2, GripVertical } from "lucide-react";
import { ScratchOffGame } from "@/components/modules/ScratchOffGame";
import { EnhancedQuiz } from "@/components/modules/EnhancedQuiz";
import { GDPRLeadForm } from "@/components/modules/GDPRLeadForm";
import type { 
  HeaderContent, TextContent, QuizContent, PrizeContent, LeadFormContent,
  headerContentSchema, textContentSchema, quizContentSchema, prizeContentSchema, leadFormContentSchema
} from "@shared/schema";

interface CampaignModule {
  id: string;
  type: 'header' | 'text' | 'quiz' | 'prize' | 'lead_form';
  content: any;
  position: number;
}

export default function EnhancedCampaignBuilder() {
  const [campaignName, setCampaignName] = useState("");
  const [campaignDescription, setCampaignDescription] = useState("");
  const [modules, setModules] = useState<CampaignModule[]>([]);
  const [editingModule, setEditingModule] = useState<CampaignModule | null>(null);
  const [isPreviewMode, setIsPreviewMode] = useState(false);

  const addModule = (type: CampaignModule['type']) => {
    const newModule: CampaignModule = {
      id: `module_${Date.now()}`,
      type,
      content: getDefaultContent(type),
      position: modules.length
    };
    setModules([...modules, newModule]);
  };

  const getDefaultContent = (type: string) => {
    switch (type) {
      case "header":
        return {
          title: "Willkommen bei unserer Kampagne",
          subtitle: "Entdecken Sie, was wir für Sie haben",
          logoUrl: ""
        };
      case "text":
        return {
          text: "Hier steht Ihr informativer Text über Ihr Unternehmen oder Produkt."
        };
      case "quiz":
        return {
          mode: "knowledge",
          questions: [
            {
              question: "Was ist das Besondere an unserem Produkt?",
              options: ["Hohe Qualität", "Niedrige Preise", "Innovative Technologie", "Alle drei"],
              correctAnswer: 3
            }
          ],
          results: {
            correct: "Glückwunsch! Sie kennen sich aus.",
            incorrect: "Fast richtig! Schauen Sie sich gerne unsere Broschüre an."
          },
          ctaText: "Mehr erfahren",
          ctaAction: "link",
          ctaLink: "https://example.com"
        };
      case "prize":
        return {
          title: "Gewinnspiel",
          instructionText: "Rubbeln Sie das Feld frei und gewinnen Sie tolle Preise!",
          winProbability: 25,
          winConfig: {
            title: "Herzlichen Glückwunsch!",
            text: "Sie haben gewonnen! Hinterlassen Sie Ihre Kontaktdaten für Ihren Gewinn.",
            action: "lead_form",
            actionData: ""
          },
          loseConfig: {
            title: "Schade!",
            text: "Dieses Mal hat es nicht geklappt, aber schauen Sie gerne an unserem Stand vorbei!"
          }
        };
      case "lead_form":
        return {
          title: "Kontaktieren Sie uns",
          fields: [
            { name: "firstName", type: "text", label: "Vorname", required: true, options: [] },
            { name: "lastName", type: "text", label: "Nachname", required: true, options: [] },
            { name: "email", type: "email", label: "E-Mail", required: true, options: [] },
            { name: "company", type: "text", label: "Unternehmen", required: false, options: [] }
          ],
          gdprText: "Ich stimme zu, dass meine Daten zur Bearbeitung meiner Anfrage gespeichert werden. Details finden Sie in unserer Datenschutzerklärung.",
          gdprLink: "https://example.com/datenschutz",
          buttonText: "Nachricht senden",
          afterSubmitAction: "thank_you",
          afterSubmitData: ""
        };
      default:
        return {};
    }
  };

  const updateModule = (id: string, content: any) => {
    setModules(modules.map(mod => 
      mod.id === id ? { ...mod, content } : mod
    ));
    setEditingModule(null);
  };

  const deleteModule = (id: string) => {
    setModules(modules.filter(mod => mod.id !== id));
  };

  const moveModule = (id: string, direction: 'up' | 'down') => {
    const index = modules.findIndex(mod => mod.id === id);
    if (direction === 'up' && index > 0) {
      const newModules = [...modules];
      [newModules[index], newModules[index - 1]] = [newModules[index - 1], newModules[index]];
      setModules(newModules);
    } else if (direction === 'down' && index < modules.length - 1) {
      const newModules = [...modules];
      [newModules[index], newModules[index + 1]] = [newModules[index + 1], newModules[index]];
      setModules(newModules);
    }
  };

  const renderModulePreview = (module: CampaignModule) => {
    switch (module.type) {
      case 'header':
        const headerContent = module.content as HeaderContent;
        return (
          <div className="text-center py-4">
            <h1 className="text-xl font-bold">{headerContent.title}</h1>
            {headerContent.subtitle && (
              <p className="text-gray-600 mt-1">{headerContent.subtitle}</p>
            )}
          </div>
        );
      case 'text':
        const textContent = module.content as TextContent;
        return (
          <div className="py-3">
            <p className="text-sm leading-relaxed">{textContent.text}</p>
          </div>
        );
      case 'quiz':
        return (
          <div className="py-2">
            <EnhancedQuiz 
              content={module.content as QuizContent}
              onQuizComplete={() => {}}
            />
          </div>
        );
      case 'prize':
        return (
          <div className="py-2">
            <ScratchOffGame 
              content={module.content as PrizeContent}
              onGameComplete={() => {}}
            />
          </div>
        );
      case 'lead_form':
        return (
          <div className="py-2">
            <GDPRLeadForm 
              content={module.content as LeadFormContent}
              campaignId="preview"
              onSubmitSuccess={() => {}}
            />
          </div>
        );
      default:
        return <div className="py-2 text-gray-500">Unbekannter Modultyp</div>;
    }
  };

  const renderModuleEditor = () => {
    if (!editingModule) return null;

    return (
      <Dialog open={!!editingModule} onOpenChange={() => setEditingModule(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingModule.type.charAt(0).toUpperCase() + editingModule.type.slice(1)} bearbeiten
            </DialogTitle>
          </DialogHeader>
          
          <ModuleEditor 
            module={editingModule}
            onSave={(content) => updateModule(editingModule.id, content)}
            onCancel={() => setEditingModule(null)}
          />
        </DialogContent>
      </Dialog>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Builder Panel */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  Kampagnen-Einstellungen
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="campaign-name">Kampagnen-Name</Label>
                  <Input
                    id="campaign-name"
                    value={campaignName}
                    onChange={(e) => setCampaignName(e.target.value)}
                    placeholder="Meine Messe-Kampagne"
                    data-testid="campaign-name-input"
                  />
                </div>
                <div>
                  <Label htmlFor="campaign-description">Beschreibung</Label>
                  <Textarea
                    id="campaign-description"
                    value={campaignDescription}
                    onChange={(e) => setCampaignDescription(e.target.value)}
                    placeholder="Kurze Beschreibung der Kampagne..."
                    data-testid="campaign-description-input"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Module Palette */}
            <Card>
              <CardHeader>
                <CardTitle>Interaktive Module hinzufügen</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                  {[
                    { type: "header", label: "Header", icon: "📄", desc: "Titel & Logo" },
                    { type: "text", label: "Text", icon: "📝", desc: "Inhalte" },
                    { type: "quiz", label: "Quiz", icon: "🤔", desc: "Wissen & Persönlichkeit" },
                    { type: "prize", label: "Gewinnspiel", icon: "🎁", desc: "Rubbel-Los" },
                    { type: "lead_form", label: "DSGVO-Form", icon: "📋", desc: "Lead-Erfassung" }
                  ].map((module) => (
                    <Button
                      key={module.type}
                      variant="outline"
                      onClick={() => addModule(module.type as CampaignModule['type'])}
                      className="h-24 flex flex-col items-center justify-center gap-1 hover:bg-primary/5"
                      data-testid={`add-module-${module.type}`}
                    >
                      <span className="text-2xl">{module.icon}</span>
                      <span className="text-xs font-medium">{module.label}</span>
                      <span className="text-[10px] text-gray-500">{module.desc}</span>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Campaign Modules */}
            <div className="space-y-4">
              {modules.length === 0 && (
                <Card className="border-dashed">
                  <CardContent className="py-12 text-center text-gray-500">
                    <Plus className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Fügen Sie interaktive Module hinzu, um Ihre Kampagne zu erstellen</p>
                    <p className="text-sm mt-2">Quiz, Gewinnspiele und Lead-Formulare steigern das Engagement</p>
                  </CardContent>
                </Card>
              )}
              
              {modules.map((module, index) => (
                <Card key={module.id} className="border-l-4 border-l-primary">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <GripVertical className="h-4 w-4 text-gray-400" />
                        <span className="font-medium capitalize">
                          {module.type === 'lead_form' ? 'DSGVO-Formular' : module.type}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-500">#{index + 1}</span>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => moveModule(module.id, 'up')}
                          disabled={index === 0}
                          data-testid={`move-up-${module.id}`}
                        >
                          ↑
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => moveModule(module.id, 'down')}
                          disabled={index === modules.length - 1}
                          data-testid={`move-down-${module.id}`}
                        >
                          ↓
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setEditingModule(module)}
                          data-testid={`edit-module-${module.id}`}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => deleteModule(module.id)}
                          data-testid={`delete-module-${module.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-gray-50 p-4 rounded">
                      {renderModulePreview(module)}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="flex gap-4">
              <Button className="flex-1" data-testid="save-campaign">
                <Save className="h-4 w-4 mr-2" />
                Kampagne speichern
              </Button>
              <Button 
                variant="outline"
                onClick={() => setIsPreviewMode(!isPreviewMode)}
                data-testid="toggle-preview"
              >
                <Eye className="h-4 w-4 mr-2" />
                {isPreviewMode ? 'Builder' : 'Vollvorschau'}
              </Button>
            </div>
          </div>

          {/* Preview Panel */}
          <div className="lg:col-span-1">
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Smartphone className="h-5 w-5" />
                  Live-Vorschau
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mx-auto w-64 h-[500px] bg-black rounded-3xl p-2">
                  <div className="w-full h-full bg-white rounded-2xl p-4 overflow-y-auto">
                    <div className="space-y-6">
                      <div className="text-center">
                        <h3 className="font-bold text-lg">{campaignName || "Ihre Kampagne"}</h3>
                        {campaignDescription && (
                          <p className="text-gray-600 text-sm mt-1">{campaignDescription}</p>
                        )}
                      </div>
                      
                      {modules.length === 0 ? (
                        <p className="text-gray-500 text-sm text-center">
                          Module erscheinen hier in der Vorschau
                        </p>
                      ) : (
                        modules.map((module) => (
                          <div key={module.id} className="border-b pb-4 last:border-b-0">
                            {renderModulePreview(module)}
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {renderModuleEditor()}
    </div>
  );
}

// Module Editor Component
interface ModuleEditorProps {
  module: CampaignModule;
  onSave: (content: any) => void;
  onCancel: () => void;
}

function ModuleEditor({ module, onSave, onCancel }: ModuleEditorProps) {
  const [content, setContent] = useState(module.content);

  const renderEditor = () => {
    switch (module.type) {
      case 'header':
        return <HeaderEditor content={content} onChange={setContent} />;
      case 'text':
        return <TextEditor content={content} onChange={setContent} />;
      case 'quiz':
        return <QuizEditor content={content} onChange={setContent} />;
      case 'prize':
        return <PrizeEditor content={content} onChange={setContent} />;
      case 'lead_form':
        return <LeadFormEditor content={content} onChange={setContent} />;
      default:
        return <div>Editor für {module.type} nicht verfügbar</div>;
    }
  };

  return (
    <div className="space-y-6">
      {renderEditor()}
      <div className="flex gap-3 pt-4">
        <Button onClick={() => onSave(content)} className="flex-1">
          Speichern
        </Button>
        <Button variant="outline" onClick={onCancel}>
          Abbrechen
        </Button>
      </div>
    </div>
  );
}

// Individual Editor Components
function HeaderEditor({ content, onChange }: { content: HeaderContent, onChange: (content: HeaderContent) => void }) {
  return (
    <div className="space-y-4">
      <div>
        <Label>Titel</Label>
        <Input
          value={content.title}
          onChange={(e) => onChange({ ...content, title: e.target.value })}
          placeholder="Haupttitel"
        />
      </div>
      <div>
        <Label>Untertitel</Label>
        <Input
          value={content.subtitle || ''}
          onChange={(e) => onChange({ ...content, subtitle: e.target.value })}
          placeholder="Optionaler Untertitel"
        />
      </div>
      <div>
        <Label>Logo URL</Label>
        <Input
          value={content.logoUrl || ''}
          onChange={(e) => onChange({ ...content, logoUrl: e.target.value })}
          placeholder="https://example.com/logo.png"
        />
      </div>
    </div>
  );
}

function TextEditor({ content, onChange }: { content: TextContent, onChange: (content: TextContent) => void }) {
  return (
    <div>
      <Label>Text</Label>
      <Textarea
        value={content.text}
        onChange={(e) => onChange({ ...content, text: e.target.value })}
        placeholder="Ihr Text hier..."
        rows={6}
      />
    </div>
  );
}

function QuizEditor({ content, onChange }: { content: QuizContent, onChange: (content: QuizContent) => void }) {
  const addQuestion = () => {
    const newQuestion = {
      question: "Neue Frage?",
      options: ["Option A", "Option B"],
      correctAnswer: content.mode === 'knowledge' ? 0 : undefined
    };
    onChange({
      ...content,
      questions: [...content.questions, newQuestion]
    });
  };

  const updateQuestion = (index: number, question: any) => {
    const newQuestions = [...content.questions];
    newQuestions[index] = question;
    onChange({ ...content, questions: newQuestions });
  };

  return (
    <div className="space-y-6">
      <div>
        <Label>Quiz-Modus</Label>
        <Select value={content.mode} onValueChange={(mode) => onChange({ ...content, mode })}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="knowledge">Wissensquiz</SelectItem>
            <SelectItem value="personality">Persönlichkeitstest</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Label>Fragen</Label>
          <Button size="sm" onClick={addQuestion}>
            <Plus className="h-4 w-4 mr-1" />
            Frage hinzufügen
          </Button>
        </div>
        
        {content.questions.map((question, index) => (
          <Card key={index} className="p-4">
            <div className="space-y-3">
              <Input
                value={question.question}
                onChange={(e) => updateQuestion(index, { ...question, question: e.target.value })}
                placeholder="Frage eingeben..."
              />
              
              {question.options.map((option, optionIndex) => (
                <div key={optionIndex} className="flex gap-2">
                  <Input
                    value={option}
                    onChange={(e) => {
                      const newOptions = [...question.options];
                      newOptions[optionIndex] = e.target.value;
                      updateQuestion(index, { ...question, options: newOptions });
                    }}
                    placeholder={`Option ${String.fromCharCode(65 + optionIndex)}`}
                  />
                  {content.mode === 'knowledge' && (
                    <Button
                      size="sm"
                      variant={question.correctAnswer === optionIndex ? "default" : "outline"}
                      onClick={() => updateQuestion(index, { ...question, correctAnswer: optionIndex })}
                    >
                      ✓
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>

      <div>
        <Label>Call-to-Action Text</Label>
        <Input
          value={content.ctaText}
          onChange={(e) => onChange({ ...content, ctaText: e.target.value })}
          placeholder="Mehr erfahren"
        />
      </div>
    </div>
  );
}

function PrizeEditor({ content, onChange }: { content: PrizeContent, onChange: (content: PrizeContent) => void }) {
  return (
    <div className="space-y-4">
      <div>
        <Label>Titel</Label>
        <Input
          value={content.title}
          onChange={(e) => onChange({ ...content, title: e.target.value })}
          placeholder="Gewinnspiel-Titel"
        />
      </div>
      
      <div>
        <Label>Anweisungstext</Label>
        <Textarea
          value={content.instructionText}
          onChange={(e) => onChange({ ...content, instructionText: e.target.value })}
          placeholder="Anweisungen für das Gewinnspiel..."
        />
      </div>
      
      <div>
        <Label>Gewinnwahrscheinlichkeit (%)</Label>
        <Input
          type="number"
          min="0"
          max="100"
          value={content.winProbability}
          onChange={(e) => onChange({ ...content, winProbability: parseInt(e.target.value) || 0 })}
        />
      </div>

      <Tabs defaultValue="win" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="win">Gewinn-Konfiguration</TabsTrigger>
          <TabsTrigger value="lose">Verlust-Konfiguration</TabsTrigger>
        </TabsList>
        
        <TabsContent value="win" className="space-y-3">
          <Input
            value={content.winConfig.title}
            onChange={(e) => onChange({
              ...content,
              winConfig: { ...content.winConfig, title: e.target.value }
            })}
            placeholder="Gewinn-Titel"
          />
          <Textarea
            value={content.winConfig.text}
            onChange={(e) => onChange({
              ...content,
              winConfig: { ...content.winConfig, text: e.target.value }
            })}
            placeholder="Gewinn-Text"
          />
        </TabsContent>
        
        <TabsContent value="lose" className="space-y-3">
          <Input
            value={content.loseConfig.title}
            onChange={(e) => onChange({
              ...content,
              loseConfig: { ...content.loseConfig, title: e.target.value }
            })}
            placeholder="Verlust-Titel"
          />
          <Textarea
            value={content.loseConfig.text}
            onChange={(e) => onChange({
              ...content,
              loseConfig: { ...content.loseConfig, text: e.target.value }
            })}
            placeholder="Verlust-Text"
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function LeadFormEditor({ content, onChange }: { content: LeadFormContent, onChange: (content: LeadFormContent) => void }) {
  const addField = () => {
    const newField = {
      name: `field_${Date.now()}`,
      type: 'text' as const,
      label: 'Neues Feld',
      required: false,
      options: []
    };
    onChange({
      ...content,
      fields: [...content.fields, newField]
    });
  };

  const updateField = (index: number, field: any) => {
    const newFields = [...content.fields];
    newFields[index] = field;
    onChange({ ...content, fields: newFields });
  };

  return (
    <div className="space-y-6">
      <div>
        <Label>Formular-Titel</Label>
        <Input
          value={content.title}
          onChange={(e) => onChange({ ...content, title: e.target.value })}
          placeholder="Kontaktformular"
        />
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Label>Formularfelder</Label>
          <Button size="sm" onClick={addField}>
            <Plus className="h-4 w-4 mr-1" />
            Feld hinzufügen
          </Button>
        </div>
        
        {content.fields.map((field, index) => (
          <Card key={index} className="p-4">
            <div className="grid grid-cols-2 gap-3">
              <Input
                value={field.label}
                onChange={(e) => updateField(index, { ...field, label: e.target.value })}
                placeholder="Feldbezeichnung"
              />
              <Select 
                value={field.type} 
                onValueChange={(type) => updateField(index, { ...field, type })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="text">Text</SelectItem>
                  <SelectItem value="email">E-Mail</SelectItem>
                  <SelectItem value="tel">Telefon</SelectItem>
                  <SelectItem value="dropdown">Dropdown</SelectItem>
                </SelectContent>
              </Select>
              <div className="flex items-center space-x-2">
                <Switch
                  checked={field.required}
                  onCheckedChange={(required) => updateField(index, { ...field, required })}
                />
                <Label>Pflichtfeld</Label>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div>
        <Label>DSGVO-Text</Label>
        <Textarea
          value={content.gdprText}
          onChange={(e) => onChange({ ...content, gdprText: e.target.value })}
          placeholder="Datenschutzeinverständnis..."
        />
      </div>

      <div>
        <Label>Datenschutz-Link</Label>
        <Input
          value={content.gdprLink}
          onChange={(e) => onChange({ ...content, gdprLink: e.target.value })}
          placeholder="https://example.com/datenschutz"
        />
      </div>

      <div>
        <Label>Button-Text</Label>
        <Input
          value={content.buttonText}
          onChange={(e) => onChange({ ...content, buttonText: e.target.value })}
          placeholder="Absenden"
        />
      </div>
    </div>
  );
}